<?php
/**
 * index.php
 * -----------------------------------------------
 * Main storefront – displays all available clothing
 * items from tblClothes using an associative array.
 * Each row includes the item image and an
 * AddToCart button that shows a SellPrice popup.
 * Student : Nkuna Kuhlula  |  ST10440743
 * -----------------------------------------------
 */

session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

require_once 'DBConn.php';

// ── Fetch all available items as associative array ─
$sql    = "SELECT * FROM tblClothes WHERE status = 'available' ORDER BY created_at DESC";
$result = $conn->query($sql);

$items = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;  // populate associative array
    }
}

$conn->close();

$fullName = htmlspecialchars($_SESSION['first_name'] . ' ' . $_SESSION['last_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop – Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- User info bar — "User John Doe is logged in" -->
<div class="user-bar">
    <span>👤 User <strong><?= $fullName ?></strong> is logged in</span>
    <div>
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="admin/dashboard.php">Admin Dashboard</a> &nbsp;|&nbsp;
        <?php endif; ?>
        <a href="logout.php">Logout</a>
    </div>
</div>

<!-- Navbar -->
<nav class="navbar">
    <a class="navbar-brand" href="index.php">Past<span>imes</span></a>
    <ul class="navbar-links">
        <li><a href="index.php">Shop</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<!-- Hero -->
<div class="hero">
    <h1>Pre-Owned <span>Branded</span> Fashion</h1>
    <p>Discover curated second-hand pieces at unbeatable prices</p>
</div>

<!-- Main Content -->
<div class="container" style="padding-top:32px;">

    <h2 style="margin-bottom:8px;">Available Items</h2>
    <p class="text-muted" style="margin-bottom:16px;font-size:0.9rem;">
        <?= count($items) ?> item<?= count($items) !== 1 ? 's' : '' ?> listed
    </p>

    <?php if (empty($items)): ?>
        <div class="alert alert-info">No items available at the moment. Check back soon!</div>
    <?php else: ?>

    <!-- Table display of items (associative columns) -->
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Brand</th>
                    <th>Size</th>
                    <th>Condition</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                <tr>
                    <!-- Image column -->
                    <td>
                        <img
                            src="images/<?= htmlspecialchars($item['image_filename']) ?>"
                            alt="<?= htmlspecialchars($item['title']) ?>"
                            style="width:70px;height:70px;object-fit:cover;border-radius:6px;"
                            onerror="this.src='images/item1.jpg'"
                        >
                    </td>
                    <td><strong><?= htmlspecialchars($item['title']) ?></strong></td>
                    <td><?= htmlspecialchars($item['brand']) ?></td>
                    <td><?= htmlspecialchars($item['size']) ?></td>
                    <td>
                        <span class="badge badge-<?= strtolower($item['item_condition']) ?>">
                            <?= htmlspecialchars($item['item_condition']) ?>
                        </span>
                    </td>
                    <td><strong style="color:var(--accent);">R <?= number_format($item['sell_price'], 2) ?></strong></td>
                    <td>
                        <!-- AddToCart button triggers price popup -->
                        <button
                            class="btn btn-primary btn-sm"
                            onclick="showCart(
                                '<?= htmlspecialchars(addslashes($item['title'])) ?>',
                                '<?= number_format($item['sell_price'], 2) ?>',
                                <?= $item['item_id'] ?>
                            )"
                        >
                            🛒 Add to Cart
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Card grid view below table -->
    <h2 style="margin-top:40px;margin-bottom:4px;">Browse as Cards</h2>
    <div class="product-grid">
        <?php foreach ($items as $item): ?>
        <div class="product-card">
            <img
                src="images/<?= htmlspecialchars($item['image_filename']) ?>"
                alt="<?= htmlspecialchars($item['title']) ?>"
                onerror="this.src='images/item1.jpg'"
            >
            <div class="product-info">
                <p class="brand"><?= htmlspecialchars($item['brand']) ?> · Size <?= htmlspecialchars($item['size']) ?></p>
                <h3><?= htmlspecialchars($item['title']) ?></h3>
                <span class="badge badge-<?= strtolower($item['item_condition']) ?>">
                    <?= htmlspecialchars($item['item_condition']) ?>
                </span>
                <p class="price">R <?= number_format($item['sell_price'], 2) ?></p>
                <button
                    class="btn btn-primary btn-sm"
                    style="width:100%;"
                    onclick="showCart(
                        '<?= htmlspecialchars(addslashes($item['title'])) ?>',
                        '<?= number_format($item['sell_price'], 2) ?>',
                        <?= $item['item_id'] ?>
                    )"
                >
                    🛒 Add to Cart
                </button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php endif; ?>
</div>

<!-- ── Price Popup / Modal ──────────────────────── -->
<div class="modal-overlay" id="cartModal">
    <div class="modal-box">
        <h2>🛒 Added to Cart!</h2>
        <p id="modalItemName" style="font-weight:600;color:var(--primary);font-size:1rem;"></p>
        <div class="price-display" id="modalPrice"></div>
        <p class="text-muted">Sell price confirmed. Item added to your cart.</p>
        <div style="display:flex;gap:12px;justify-content:center;">
            <button class="btn btn-secondary" onclick="closeModal()">Continue Shopping</button>
            <a href="cart.php" class="btn btn-primary">View Cart</a>
        </div>
    </div>
</div>

<footer>
    <p>&copy; <?= date('Y') ?> <span>Pastimes</span> – Pre-owned Branded Clothing | ST10440743</p>
</footer>

<script>
/**
 * showCart()
 * Displays the SellPrice popup and returns to table (as per rubric).
 * Adds item to session cart via AJAX.
 */
function showCart(title, price, itemId) {
    document.getElementById('modalItemName').textContent = title;
    document.getElementById('modalPrice').textContent    = 'R ' + price;
    document.getElementById('cartModal').classList.add('active');

    // Add to cart via fetch
    fetch('addToCart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'item_id=' + itemId
    });
}

function closeModal() {
    document.getElementById('cartModal').classList.remove('active');
}

// Close modal clicking outside
document.getElementById('cartModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});
</script>

</body>
</html>
