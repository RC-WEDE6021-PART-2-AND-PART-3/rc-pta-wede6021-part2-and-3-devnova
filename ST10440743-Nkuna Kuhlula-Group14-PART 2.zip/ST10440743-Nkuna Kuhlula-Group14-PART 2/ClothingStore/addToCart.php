<?php
/**
 * addToCart.php
 * Adds an item to the session-based cart.
 * Called via AJAX from index.php.
 */
session_start();
require_once 'DBConn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['item_id'])) {
    $itemId = (int) $_POST['item_id'];

    // Fetch item details
    $stmt = $conn->prepare("SELECT item_id, title, sell_price, image_filename FROM tblClothes WHERE item_id = ? AND status = 'available'");
    $stmt->bind_param('i', $itemId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $item = $result->fetch_assoc();

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Add or increment quantity
        if (isset($_SESSION['cart'][$itemId])) {
            $_SESSION['cart'][$itemId]['quantity']++;
        } else {
            $_SESSION['cart'][$itemId] = [
                'item_id'        => $item['item_id'],
                'title'          => $item['title'],
                'sell_price'     => $item['sell_price'],
                'image_filename' => $item['image_filename'],
                'quantity'       => 1,
            ];
        }
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'msg' => 'Item not found']);
    }

    $stmt->close();
}
$conn->close();
?>
