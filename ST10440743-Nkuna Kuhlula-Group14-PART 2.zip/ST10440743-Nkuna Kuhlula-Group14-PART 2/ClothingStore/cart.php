<?php
/**
 * cart.php – Shopping cart view for Pastimes
 */
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

$cart  = $_SESSION['cart'] ?? [];
$total = 0;
foreach ($cart as $item) {
    $total += $item['sell_price'] * $item['quantity'];
}
$fullName = htmlspecialchars($_SESSION['first_name'] . ' ' . $_SESSION['last_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cart – Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="user-bar">
    <span>👤 User <strong><?= $fullName ?></strong> is logged in</span>
    <a href="logout.php">Logout</a>
</div>
<nav class="navbar">
    <a class="navbar-brand" href="index.php">Past<span>imes</span></a>
    <ul class="navbar-links">
        <li><a href="index.php">Shop</a></li>
        <li><a href="cart.php">Cart (<?= count($cart) ?>)</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<div class="container" style="padding-top:32px;">
    <h2 style="margin-bottom:20px;">Your Cart</h2>

    <?php if (empty($cart)): ?>
        <div class="alert alert-info">Your cart is empty. <a href="index.php">Keep browsing!</a></div>
    <?php else: ?>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr><th>Image</th><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th><th>Remove</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($cart as $id => $item): ?>
                    <tr>
                        <td><img src="images/<?= htmlspecialchars($item['image_filename']) ?>" style="width:60px;height:60px;object-fit:cover;border-radius:6px;" onerror="this.src='images/item1.jpg'"></td>
                        <td><?= htmlspecialchars($item['title']) ?></td>
                        <td>R <?= number_format($item['sell_price'], 2) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td><strong>R <?= number_format($item['sell_price'] * $item['quantity'], 2) ?></strong></td>
                        <td><a href="removeFromCart.php?id=<?= $id ?>" class="btn btn-danger btn-sm">Remove</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4" style="text-align:right;padding:14px 16px;font-weight:700;">Total:</td>
                        <td colspan="2" style="font-size:1.1rem;font-weight:700;color:var(--accent);padding:14px 16px;">R <?= number_format($total, 2) ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div style="margin-top:20px;display:flex;gap:12px;">
            <a href="index.php" class="btn btn-secondary">← Continue Shopping</a>
            <a href="checkout.php" class="btn btn-primary">Checkout →</a>
        </div>
    <?php endif; ?>
</div>

<footer><p>&copy; <?= date('Y') ?> <span>Pastimes</span> | ST10440743</p></footer>
</body>
</html>
