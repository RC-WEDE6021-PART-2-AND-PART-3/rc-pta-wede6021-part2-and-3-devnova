-- ============================================================
--  myClothingStore.sql
--  DDL script for the ClothingStore database
--  Student : Nkuna Kuhlula  |  ST10440743
--  Module  : WEDE6020  |  Part 2
-- ============================================================

-- Drop and recreate the database
DROP DATABASE IF EXISTS ClothingStore;
CREATE DATABASE ClothingStore
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE ClothingStore;

-- ── Table: tblUser ─────────────────────────────────────────
DROP TABLE IF EXISTS tblUser;
CREATE TABLE tblUser (
    user_id      INT          NOT NULL AUTO_INCREMENT,
    first_name   VARCHAR(50)  NOT NULL,
    last_name    VARCHAR(50)  NOT NULL,
    email        VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone        VARCHAR(20)  DEFAULT NULL,
    role         VARCHAR(20)  NOT NULL DEFAULT 'pending',
    is_verified  TINYINT(1)   NOT NULL DEFAULT 0,
    created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id)
) ENGINE=InnoDB;

-- ── Table: tblAdmin ────────────────────────────────────────
DROP TABLE IF EXISTS tblAdmin;
CREATE TABLE tblAdmin (
    admin_id      INT          NOT NULL AUTO_INCREMENT,
    first_name    VARCHAR(50)  NOT NULL,
    last_name     VARCHAR(50)  NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (admin_id)
) ENGINE=InnoDB;

-- ── Table: tblClothes ──────────────────────────────────────
DROP TABLE IF EXISTS tblClothes;
CREATE TABLE tblClothes (
    item_id        INT            NOT NULL AUTO_INCREMENT,
    title          VARCHAR(100)   NOT NULL,
    brand          VARCHAR(50)    NOT NULL,
    size           VARCHAR(10)    NOT NULL,
    item_condition VARCHAR(20)    NOT NULL DEFAULT 'Good',
    sell_price     DECIMAL(10,2)  NOT NULL,
    image_filename VARCHAR(100)   NOT NULL,
    description    TEXT           DEFAULT NULL,
    status         VARCHAR(20)    NOT NULL DEFAULT 'available',
    created_at     TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (item_id)
) ENGINE=InnoDB;

-- ── Table: tblAorder ───────────────────────────────────────
DROP TABLE IF EXISTS tblAorder;
CREATE TABLE tblAorder (
    order_id    INT         NOT NULL AUTO_INCREMENT,
    user_id     INT         NOT NULL,
    item_id     INT         NOT NULL,
    quantity    INT         NOT NULL DEFAULT 1,
    order_date  TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status      VARCHAR(20) NOT NULL DEFAULT 'placed',
    PRIMARY KEY (order_id),
    CONSTRAINT fk_order_user   FOREIGN KEY (user_id) REFERENCES tblUser(user_id)  ON DELETE CASCADE,
    CONSTRAINT fk_order_item   FOREIGN KEY (item_id) REFERENCES tblClothes(item_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
--  SEED DATA  (30 entries total across all tables)
-- ============================================================

-- ── tblUser seed data (10 rows) ────────────────────────────
-- Passwords: row 1-5 use 'password','123456','letmein','welcome','qwerty'
--            row 6-10 use 'pass1','pass2','pass3','pass4','pass5'
INSERT INTO tblUser (first_name, last_name, email, password_hash, phone, role, is_verified) VALUES
('John',    'Doe',      'j.doe@abc.co.za',            '5f4dcc3b5aa765d61d8327deb882cf99', '0821234567', 'customer', 1),
('Jane',    'Smith',    'j.smith@pastimes.co.za',      'e10adc3949ba59abbe56e057f20f883e', '0831234567', 'customer', 1),
('Mike',    'Johnson',  'm.johnson@gmail.com',          '0d107d09f5bbe40cade3de5c71e9e9b7', '0841234567', 'customer', 1),
('Sarah',   'Williams', 's.williams@yahoo.co.za',      '40be4e59b9a2a2b5dffb918c0e86b3d7', '0851234567', 'customer', 1),
('David',   'Brown',    'd.brown@outlook.com',          'd8578edf8458ce06fbc5bb76a58c5ca4', '0861234567', 'customer', 1),
('Lerato',  'Mokoena',  'l.mokoena@gmail.com',          '1a1dc91c907325c69271ddf0c944bc72', '0711234567', 'customer', 1),
('Thabo',   'Dlamini',  't.dlamini@webmail.co.za',     'b14a7b8059d9c055954c92674ce60032', '0721234567', 'customer', 1),
('Nomsa',   'Zulu',     'n.zulu@pastimes.co.za',        '6512bd43d9caa6e02c990b0a82652dca', '0731234567', 'pending',  0),
('Sipho',   'Ndlovu',   's.ndlovu@gmail.com',           'c20ad4d76fe97759aa27a0c99bff6710', '0741234567', 'pending',  0),
('Ayanda',  'Khumalo',  'a.khumalo@icloud.com',        'c51ce410c124a10e0db5e4b97fc2af39', '0751234567', 'pending',  0);

-- ── tblAdmin seed data (3 rows) ────────────────────────────
-- Admin password: 'admin123' => md5 = 0192023a7bbd73250516f069df18b500
INSERT INTO tblAdmin (first_name, last_name, email, password_hash) VALUES
('Admin',   'Pastimes', 'admin@pastimes.co.za',  '0192023a7bbd73250516f069df18b500'),
('Super',   'Admin',    'super@pastimes.co.za',   '0192023a7bbd73250516f069df18b500'),
('Manager', 'Store',    'manager@pastimes.co.za', '0192023a7bbd73250516f069df18b500');

-- ── tblClothes seed data (12 rows) ─────────────────────────
INSERT INTO tblClothes (title, brand, size, item_condition, sell_price, image_filename, description) VALUES
("Levi's 501 Original Jeans",       'Levis',   '32',  'Good',      499.00,  'item1.jpg', 'Classic straight-leg denim jeans, lightly worn.'),
('Nike Air Max Hoodie',              'Nike',    'L',   'Excellent', 650.00,  'item2.jpg', 'Navy blue pullover hoodie, worn twice.'),
('Adidas Windbreaker Jacket',        'Adidas',  'M',   'Good',      420.00,  'item3.jpg', 'Black and white zip-up windbreaker.'),
('Gucci Leather Belt',               'Gucci',   'M',   'Excellent', 1200.00, 'item4.jpg', 'Authentic Gucci GG belt, black leather.'),
('Puma RS-X Sneakers',               'Puma',    '9',   'Fair',      350.00,  'item5.jpg', 'White and blue sneakers, minor sole wear.'),
('Tommy Hilfiger Polo Shirt',        'Tommy',   'L',   'Excellent', 380.00,  'item1.jpg', 'Navy polo, no marks or tears.'),
('H&M Trench Coat',                  'H&M',     'S',   'Good',      550.00,  'item2.jpg', 'Beige classic trench, worn a few times.'),
('Zara High-Waist Trousers',         'Zara',    'XS',  'Excellent', 290.00,  'item3.jpg', 'Black tailored trousers, like new.'),
('New Balance 990 Sneakers',         'NB',      '8',   'Good',      720.00,  'item4.jpg', 'Grey running shoes, minimal wear.'),
('Ralph Lauren Oxford Shirt',        'RL',      'M',   'Good',      450.00,  'item5.jpg', 'Light blue button-down, iron pressed.'),
('Woolworths Denim Skirt',           'WW',      'S',   'Excellent', 220.00,  'item1.jpg', 'Mid-length denim skirt, no fading.'),
('Supreme Box Logo Hoodie',          'Supreme', 'L',   'Good',      1800.00, 'item2.jpg', 'Red box logo hoodie, authentic, light pilling.');

-- ── tblAorder seed data (5 rows) ───────────────────────────
INSERT INTO tblAorder (user_id, item_id, quantity, status) VALUES
(1, 1, 1, 'delivered'),
(2, 3, 1, 'dispatched'),
(3, 5, 2, 'placed'),
(4, 7, 1, 'delivered'),
(5, 9, 1, 'placed');
