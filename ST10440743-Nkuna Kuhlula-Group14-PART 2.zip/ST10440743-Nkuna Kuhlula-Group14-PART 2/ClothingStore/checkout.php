<?php
/**
 * checkout.php – Confirms order and saves to tblAorder
 */
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

require_once 'DBConn.php';

$cart     = $_SESSION['cart'] ?? [];
$message  = '';
$success  = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($cart)) {
    $userId = (int) $_SESSION['user_id'];

    $stmt = $conn->prepare(
        "INSERT INTO tblAorder (user_id, item_id, quantity, status) VALUES (?, ?, ?, 'placed')"
    );

    foreach ($cart as $item) {
        $itemId = (int) $item['item_id'];
        $qty    = (int) $item['quantity'];
        $stmt->bind_param('iii', $userId, $itemId, $qty);
        $stmt->execute();
    }

    $stmt->close();
    $_SESSION['cart'] = [];
    $success = true;
    $message = 'Your order has been placed successfully! An admin will confirm your delivery soon.';
}

$conn->close();
$total = 0;
foreach ($cart as $item) { $total += $item['sell_price'] * $item['quantity']; }
$fullName = htmlspecialchars($_SESSION['first_name'] . ' ' . $_SESSION['last_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout – Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="user-bar">
    <span>👤 User <strong><?= $fullName ?></strong> is logged in</span>
    <a href="logout.php">Logout</a>
</div>
<nav class="navbar">
    <a class="navbar-brand" href="index.php">Past<span>imes</span></a>
    <ul class="navbar-links">
        <li><a href="index.php">Shop</a></li>
        <li><a href="cart.php">Cart</a></li>
    </ul>
</nav>

<div class="container" style="padding-top:32px;max-width:700px;">
    <div class="card">
        <div class="card-header"><h2>Checkout</h2><p>Confirm your order below</p></div>
        <div class="card-body">
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $message ?></div>
                <a href="index.php" class="btn btn-primary">Back to Shop</a>
            <?php elseif (empty($cart)): ?>
                <div class="alert alert-warning">Your cart is empty. <a href="index.php">Go shopping</a></div>
            <?php else: ?>
                <table style="width:100%;margin-bottom:20px;">
                    <thead><tr><th>Item</th><th>Qty</th><th>Price</th></tr></thead>
                    <tbody>
                        <?php foreach ($cart as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['title']) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td>R <?= number_format($item['sell_price'] * $item['quantity'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr><td colspan="2" style="text-align:right;font-weight:700;">Total:</td>
                        <td style="font-weight:700;color:var(--accent);">R <?= number_format($total, 2) ?></td></tr>
                    </tfoot>
                </table>
                <form method="POST">
                    <button type="submit" class="btn btn-primary">Confirm Order</button>
                    <a href="cart.php" class="btn btn-secondary" style="margin-left:10px;">← Back to Cart</a>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<footer><p>&copy; <?= date('Y') ?> <span>Pastimes</span> | ST10440743</p></footer>
</body>
</html>
