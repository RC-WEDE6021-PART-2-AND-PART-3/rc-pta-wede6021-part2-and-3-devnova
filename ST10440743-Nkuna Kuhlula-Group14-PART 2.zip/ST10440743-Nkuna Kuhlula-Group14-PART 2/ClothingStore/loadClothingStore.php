<?php
/**
 * loadClothingStore.php
 * -----------------------------------------------
 * Drops all tables (if they exist) and recreates
 * them fresh in the ClothingStore database.
 * Uses MySQLi with an include of DBConn.php.
 * Student : Nkuna Kuhlula  |  ST10440743
 * Module  : WEDE6020  |  Part 2
 * -----------------------------------------------
 */

// ── Include the database connection ──────────────
require_once 'DBConn.php';

// ── Collect results to display on screen ─────────
$results = [];

/**
 * dropTable()
 * Drops a table if it exists and records the outcome.
 *
 * @param mysqli $conn   Active MySQLi connection
 * @param string $table  Table name to drop
 * @param array  &$log   Reference to results log array
 */
function dropTable(mysqli $conn, string $table, array &$log): void
{
    $sql = "DROP TABLE IF EXISTS `$table`";
    if ($conn->query($sql)) {
        $log[] = ['status' => 'success', 'msg' => "✔ Table <strong>$table</strong> dropped (or did not exist)."];
    } else {
        $log[] = ['status' => 'error', 'msg' => "✘ Could not drop <strong>$table</strong>: " . $conn->error];
    }
}

/**
 * runQuery()
 * Executes a CREATE TABLE query and records the outcome.
 *
 * @param mysqli $conn  Active MySQLi connection
 * @param string $sql   Full CREATE TABLE statement
 * @param string $label Friendly name for logging
 * @param array  &$log  Reference to results log array
 */
function runQuery(mysqli $conn, string $sql, string $label, array &$log): void
{
    if ($conn->query($sql)) {
        $log[] = ['status' => 'success', 'msg' => "✔ Table <strong>$label</strong> created successfully."];
    } else {
        $log[] = ['status' => 'error', 'msg' => "✘ Failed to create <strong>$label</strong>: " . $conn->error];
    }
}

// ── Step 1: Drop existing tables (FK order matters) ──
$conn->query("SET FOREIGN_KEY_CHECKS = 0");
dropTable($conn, 'tblAorder',  $results);
dropTable($conn, 'tblClothes', $results);
dropTable($conn, 'tblAdmin',   $results);
dropTable($conn, 'tblUser',    $results);
$conn->query("SET FOREIGN_KEY_CHECKS = 1");

// ── Step 2: Create tblUser ────────────────────────
$sqlUser = "
    CREATE TABLE tblUser (
        user_id       INT           NOT NULL AUTO_INCREMENT,
        first_name    VARCHAR(50)   NOT NULL,
        last_name     VARCHAR(50)   NOT NULL,
        email         VARCHAR(100)  NOT NULL UNIQUE,
        password_hash VARCHAR(255)  NOT NULL,
        phone         VARCHAR(20)   DEFAULT NULL,
        role          VARCHAR(20)   NOT NULL DEFAULT 'pending',
        is_verified   TINYINT(1)    NOT NULL DEFAULT 0,
        created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";
runQuery($conn, $sqlUser, 'tblUser', $results);

// ── Step 3: Create tblAdmin ───────────────────────
$sqlAdmin = "
    CREATE TABLE tblAdmin (
        admin_id      INT           NOT NULL AUTO_INCREMENT,
        first_name    VARCHAR(50)   NOT NULL,
        last_name     VARCHAR(50)   NOT NULL,
        email         VARCHAR(100)  NOT NULL UNIQUE,
        password_hash VARCHAR(255)  NOT NULL,
        created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (admin_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";
runQuery($conn, $sqlAdmin, 'tblAdmin', $results);

// ── Step 4: Create tblClothes ─────────────────────
$sqlClothes = "
    CREATE TABLE tblClothes (
        item_id        INT            NOT NULL AUTO_INCREMENT,
        title          VARCHAR(100)   NOT NULL,
        brand          VARCHAR(50)    NOT NULL,
        size           VARCHAR(10)    NOT NULL,
        item_condition VARCHAR(20)    NOT NULL DEFAULT 'Good',
        sell_price     DECIMAL(10,2)  NOT NULL,
        image_filename VARCHAR(100)   NOT NULL,
        description    TEXT           DEFAULT NULL,
        status         VARCHAR(20)    NOT NULL DEFAULT 'available',
        created_at     TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (item_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";
runQuery($conn, $sqlClothes, 'tblClothes', $results);

// ── Step 5: Create tblAorder ─────────────────────
$sqlOrder = "
    CREATE TABLE tblAorder (
        order_id   INT         NOT NULL AUTO_INCREMENT,
        user_id    INT         NOT NULL,
        item_id    INT         NOT NULL,
        quantity   INT         NOT NULL DEFAULT 1,
        order_date TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
        status     VARCHAR(20) NOT NULL DEFAULT 'placed',
        PRIMARY KEY (order_id),
        CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES tblUser(user_id)    ON DELETE CASCADE,
        CONSTRAINT fk_order_item FOREIGN KEY (item_id) REFERENCES tblClothes(item_id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";
runQuery($conn, $sqlOrder, 'tblAorder', $results);

// ── Step 6: Seed default admin account ───────────
// Admin password: admin123  (md5 = 0192023a7bbd73250516f069df18b500)
$seedAdmin = "
    INSERT INTO tblAdmin (first_name, last_name, email, password_hash)
    VALUES ('Admin', 'Pastimes', 'admin@pastimes.co.za', '0192023a7bbd73250516f069df18b500')
";
if ($conn->query($seedAdmin)) {
    $results[] = ['status' => 'success', 'msg' => '✔ Default admin account seeded (admin@pastimes.co.za / admin123).'];
} else {
    $results[] = ['status' => 'error',   'msg' => '✘ Admin seed failed: ' . $conn->error];
}

// ── Step 7: Seed sample clothing items ───────────
$seedClothes = "
    INSERT INTO tblClothes (title, brand, size, item_condition, sell_price, image_filename, description) VALUES
    ('Levi\\'s 501 Original Jeans',  'Levis',   '32', 'Good',      499.00,  'item1.jpg', 'Classic straight-leg denim jeans, lightly worn.'),
    ('Nike Air Max Hoodie',           'Nike',    'L',  'Excellent', 650.00,  'item2.jpg', 'Navy blue pullover hoodie, worn twice.'),
    ('Adidas Windbreaker Jacket',     'Adidas',  'M',  'Good',      420.00,  'item3.jpg', 'Black and white zip-up windbreaker.'),
    ('Gucci Leather Belt',            'Gucci',   'M',  'Excellent', 1200.00, 'item4.jpg', 'Authentic Gucci GG belt, black leather.'),
    ('Puma RS-X Sneakers',            'Puma',    '9',  'Fair',      350.00,  'item5.jpg', 'White and blue sneakers, minor sole wear.')
";
if ($conn->query($seedClothes)) {
    $results[] = ['status' => 'success', 'msg' => '✔ Sample clothing items seeded (5 records).'];
} else {
    $results[] = ['status' => 'error',   'msg' => '✘ Clothes seed failed: ' . $conn->error];
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Load ClothingStore – Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container" style="max-width:700px;margin:40px auto;">
    <div class="card">
        <div class="card-header">
            <h1>⚙ loadClothingStore.php</h1>
            <p>ClothingStore database setup complete</p>
        </div>
        <div class="card-body">
            <?php foreach ($results as $row): ?>
                <div class="alert <?= $row['status'] === 'success' ? 'alert-success' : 'alert-danger' ?>">
                    <?= $row['msg'] ?>
                </div>
            <?php endforeach; ?>
            <hr>
            <a href="login.php" class="btn btn-primary">Go to Login</a>
            &nbsp;
            <a href="createTable.php" class="btn btn-secondary">Run createTable.php</a>
        </div>
    </div>
</div>
</body>
</html>
