<?php
/**
 * createTable.php
 * -----------------------------------------------
 * Checks if tblUser exists – if it does, drops it,
 * recreates it and loads data from userData.txt.
 * DBConn.php is included as a connection file.
 * Student : Nkuna Kuhlula  |  ST10440743
 * Module  : WEDE6020  |  Part 2
 * -----------------------------------------------
 */

// ── Include DB connection ─────────────────────────
require_once 'DBConn.php';

$log = [];

// ── Step 1: Check if tblUser already exists ───────
$checkSql = "SHOW TABLES LIKE 'tblUser'";
$result   = $conn->query($checkSql);

if ($result && $result->num_rows > 0) {
    // Table exists – drop it
    $conn->query("DROP TABLE IF EXISTS tblUser");
    $log[] = ['status' => 'info', 'msg' => '🗑 tblUser existed and was dropped.'];
} else {
    $log[] = ['status' => 'info', 'msg' => 'ℹ tblUser did not exist. Creating fresh.'];
}

// ── Step 2: Recreate tblUser ──────────────────────
$createSql = "
    CREATE TABLE tblUser (
        user_id       INT           NOT NULL AUTO_INCREMENT,
        first_name    VARCHAR(50)   NOT NULL,
        last_name     VARCHAR(50)   NOT NULL,
        email         VARCHAR(100)  NOT NULL UNIQUE,
        password_hash VARCHAR(255)  NOT NULL,
        phone         VARCHAR(20)   DEFAULT NULL,
        role          VARCHAR(20)   NOT NULL DEFAULT 'pending',
        is_verified   TINYINT(1)    NOT NULL DEFAULT 0,
        created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if ($conn->query($createSql)) {
    $log[] = ['status' => 'success', 'msg' => '✔ tblUser created successfully.'];
} else {
    $log[] = ['status' => 'error', 'msg' => '✘ Failed to create tblUser: ' . $conn->error];
}

// ── Step 3: Load userData.txt into tblUser ────────
$txtFile = __DIR__ . '/userData.txt';

if (!file_exists($txtFile)) {
    $log[] = ['status' => 'error', 'msg' => '✘ userData.txt not found in project root.'];
} else {
    $lines   = file($txtFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $loaded  = 0;
    $skipped = 0;

    // Prepare a parameterised INSERT statement
    $stmt = $conn->prepare(
        "INSERT INTO tblUser (first_name, last_name, email, password_hash, phone, role, is_verified)
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );

    foreach ($lines as $line) {
        // Format: first_name|last_name|email|password_hash|phone|role|is_verified
        $parts = explode('|', $line);

        if (count($parts) < 7) {
            $skipped++;
            continue;
        }

        [$first, $last, $email, $hash, $phone, $role, $verified] = $parts;
        $verified = (int) trim($verified);

        $stmt->bind_param('ssssssi',
            $first, $last, $email, $hash, $phone, $role, $verified
        );

        if ($stmt->execute()) {
            $loaded++;
        } else {
            $skipped++;
        }
    }

    $stmt->close();
    $log[] = ['status' => 'success', 'msg' => "✔ userData.txt loaded – <strong>$loaded</strong> row(s) inserted, $skipped skipped."];
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>createTable – Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container" style="max-width:700px;margin:40px auto;">
    <div class="card">
        <div class="card-header">
            <h1>📋 createTable.php</h1>
            <p>tblUser setup and data load from userData.txt</p>
        </div>
        <div class="card-body">
            <?php foreach ($log as $entry): ?>
                <div class="alert alert-<?= $entry['status'] === 'success' ? 'success' : ($entry['status'] === 'info' ? 'info' : 'danger') ?>">
                    <?= $entry['msg'] ?>
                </div>
            <?php endforeach; ?>
            <hr>
            <a href="login.php" class="btn btn-primary">Go to Login</a>
        </div>
    </div>
</div>
</body>
</html>
