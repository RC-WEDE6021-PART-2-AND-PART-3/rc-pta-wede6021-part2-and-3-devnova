<?php
/**
 * DBConn.php
 * -----------------------------------------------
 * Establishes a MySQLi connection to ClothingStore
 * Student : Nkuna Kuhlula  |  ST10440743
 * Module  : WEDE6020  |  Part 2
 * -----------------------------------------------
 */

// ── Database credentials ─────────────────────────
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ClothingStore');

// ── Create the MySQLi connection ─────────────────
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// ── Validate connection ───────────────────────────
if ($conn->connect_error) {
    die(
        '<div style="font-family:Calibri;color:#c0392b;padding:20px;">'
        . '<strong>Database connection failed:</strong> '
        . $conn->connect_error
        . '</div>'
    );
}

// Set character encoding to UTF-8
$conn->set_charset('utf8mb4');
?>
