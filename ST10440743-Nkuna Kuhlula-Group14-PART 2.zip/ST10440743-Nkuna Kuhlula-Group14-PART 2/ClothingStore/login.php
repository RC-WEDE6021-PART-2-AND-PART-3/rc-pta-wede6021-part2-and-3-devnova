<?php
/**
 * login.php
 * -----------------------------------------------
 * Login page for Pastimes.
 * - Accepts username (email) + password
 * - Compares password to MD5 hash in tblUser
 * - Sticky form if password is wrong
 * - Displays "User John Doe is logged in" on success
 * - HTML5 required validation on all fields
 * - New users can register via register.php
 * Student : Nkuna Kuhlula  |  ST10440743
 * -----------------------------------------------
 */

session_start();

// If already logged in, redirect
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'DBConn.php';

$error    = '';
$email    = '';  // sticky field value

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Sanitise inputs
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        // Hash the submitted password with MD5 to compare
        $hashedInput = md5($password);

        // Fetch user by email using prepared statement
        $stmt = $conn->prepare(
            "SELECT user_id, first_name, last_name, password_hash, role, is_verified
             FROM tblUser
             WHERE email = ?"
        );
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if ($hashedInput === $user['password_hash']) {
                // ── Password correct ──────────────────────
                if ($user['is_verified'] == 0) {
                    $error = 'Your account is pending administrator verification. Please wait for approval.';
                } else {
                    // Start session
                    $_SESSION['user_id']    = $user['user_id'];
                    $_SESSION['first_name'] = $user['first_name'];
                    $_SESSION['last_name']  = $user['last_name'];
                    $_SESSION['role']       = $user['role'];
                    $_SESSION['email']      = $email;

                    header('Location: index.php');
                    exit;
                }
            } else {
                // ── Wrong password – sticky form ──────────
                $error = 'Incorrect password. Please try again.';
                // $email stays populated (sticky) – password field cleared intentionally
            }
        } else {
            $error = 'No account found with that email address. Please register.';
        }
        $stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login – Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar">
    <a class="navbar-brand" href="login.php">Past<span>imes</span></a>
    <ul class="navbar-links">
        <li><a href="login.php">Login</a></li>
        <li><a href="register.php">Register</a></li>
    </ul>
</nav>

<!-- Auth Wrapper -->
<div class="auth-wrapper">
    <div class="auth-box">

        <div class="auth-header">
            <h2>Welcome Back</h2>
            <p>Sign in to your Pastimes account</p>
        </div>

        <div class="auth-body">

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="login.php" novalidate>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        class="form-control"
                        placeholder="you@example.com"
                        value="<?= htmlspecialchars($email) ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        class="form-control"
                        placeholder="Enter your password"
                        required
                        minlength="4"
                    >
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;margin-top:6px;">
                    Sign In
                </button>

            </form>

            <hr>

            <p class="text-center text-muted" style="font-size:0.88rem;">
                Don't have an account?
                <a href="register.php" style="color:var(--accent);font-weight:500;">Register here</a>
            </p>

            <p class="text-center text-muted" style="font-size:0.82rem;margin-top:8px;">
                <a href="admin/adminLogin.php" style="color:var(--text-muted);">Admin login →</a>
            </p>

        </div>
    </div>
</div>

<footer>
    <p>&copy; <?= date('Y') ?> <span>Pastimes</span> – Pre-owned Branded Clothing | ST10440743</p>
</footer>

</body>
</html>
