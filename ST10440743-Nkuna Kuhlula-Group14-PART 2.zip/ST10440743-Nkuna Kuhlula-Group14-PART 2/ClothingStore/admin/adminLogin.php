<?php
/**
 * admin/adminLogin.php
 * -----------------------------------------------
 * Admin login page.
 * - Email must match tblAdmin.email
 * - Password compared against MD5 hash in tblAdmin
 * - Separate session key 'admin_id' used
 * - Admin email address validated (admin@pastimes.co.za)
 * Student : Nkuna Kuhlula  |  ST10440743
 * -----------------------------------------------
 */

session_start();

if (isset($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

require_once '../DBConn.php';

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($email) || empty($password)) {
        $error = 'Please enter your admin email and password.';
    } else {
        $hashed = md5($password);

        $stmt = $conn->prepare(
            "SELECT admin_id, first_name, last_name, password_hash
             FROM tblAdmin
             WHERE email = ?"
        );
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();

            if ($hashed === $admin['password_hash']) {
                // ── Verified admin ────────────────────────
                $_SESSION['admin_id']         = $admin['admin_id'];
                $_SESSION['admin_first_name'] = $admin['first_name'];
                $_SESSION['admin_last_name']  = $admin['last_name'];
                $_SESSION['admin_email']      = $email;

                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Incorrect password. Please try again.';
            }
        } else {
            $error = 'No admin account found with that email address.';
        }
        $stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login – Pastimes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body style="background:#0f0f1a;">

<nav class="navbar">
    <a class="navbar-brand" href="../login.php">Past<span>imes</span></a>
    <ul class="navbar-links">
        <li><a href="../login.php">Customer Login</a></li>
    </ul>
</nav>

<div class="auth-wrapper">
    <div class="auth-box">
        <div class="auth-header" style="background:#0f0f1a;">
            <h2>⚙ Admin Portal</h2>
            <p>Authorised personnel only</p>
        </div>
        <div class="auth-body">

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <div class="alert alert-info" style="font-size:0.82rem;margin-bottom:18px;">
                <strong>Demo credentials:</strong><br>
                Email: admin@pastimes.co.za &nbsp;|&nbsp; Password: admin123
            </div>

            <form method="POST" action="adminLogin.php">

                <div class="form-group">
                    <label for="email">Admin Email</label>
                    <input type="email" id="email" name="email" class="form-control"
                           placeholder="admin@pastimes.co.za"
                           value="<?= htmlspecialchars($email) ?>" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control"
                           placeholder="Admin password" required>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;">
                    Sign In as Admin
                </button>

            </form>

            <hr>
            <p class="text-center" style="font-size:0.85rem;">
                <a href="../login.php" style="color:var(--text-muted);">← Customer login</a>
            </p>

        </div>
    </div>
</div>

<footer>
    <p>&copy; <?= date('Y') ?> <span>Pastimes</span> – Admin Portal | ST10440743</p>
</footer>

</body>
</html>
