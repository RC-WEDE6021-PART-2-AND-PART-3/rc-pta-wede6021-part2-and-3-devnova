<?php
/**
 * admin/dashboard.php
 * -----------------------------------------------
 * Admin dashboard for Pastimes.
 * Features:
 *  - Verify pending user registrations
 *  - Add new customers
 *  - Update existing customer details
 *  - Delete customers
 *  - View all users in a table
 * Student : Nkuna Kuhlula  |  ST10440743
 * -----------------------------------------------
 */

session_start();

// Guard – admin only
if (!isset($_SESSION['admin_id'])) {
    header('Location: adminLogin.php');
    exit;
}

require_once '../DBConn.php';

$message = '';
$msgType = 'success';

// ── Determine action ──────────────────────────────
$action = $_GET['action'] ?? '';
$userId = isset($_GET['uid']) ? (int) $_GET['uid'] : 0;

// ── Verify a pending user ─────────────────────────
if ($action === 'verify' && $userId > 0) {
    $stmt = $conn->prepare("UPDATE tblUser SET is_verified = 1, role = 'customer' WHERE user_id = ?");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->close();
    $message = 'User has been verified and can now log in.';
}

// ── Delete a user ─────────────────────────────────
if ($action === 'delete' && $userId > 0) {
    $stmt = $conn->prepare("DELETE FROM tblUser WHERE user_id = ?");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->close();
    $message = 'User deleted successfully.';
}

// ── Add new customer ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $fn    = trim($_POST['first_name'] ?? '');
    $ln    = trim($_POST['last_name']  ?? '');
    $em    = trim($_POST['email']      ?? '');
    $ph    = trim($_POST['phone']      ?? '');
    $pw    = trim($_POST['password']   ?? '');

    if ($fn && $ln && $em && $pw) {
        $hash = md5($pw);
        $stmt = $conn->prepare(
            "INSERT INTO tblUser (first_name, last_name, email, password_hash, phone, role, is_verified)
             VALUES (?, ?, ?, ?, ?, 'customer', 1)"
        );
        $stmt->bind_param('sssss', $fn, $ln, $em, $hash, $ph);
        if ($stmt->execute()) {
            $message = "New customer <strong>$fn $ln</strong> added successfully.";
        } else {
            $message = 'Failed to add customer (email may already exist).';
            $msgType = 'danger';
        }
        $stmt->close();
    } else {
        $message = 'Please fill in all required fields.';
        $msgType = 'danger';
    }
}

// ── Update customer ───────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $uid = (int) $_POST['edit_user_id'];
    $fn  = trim($_POST['edit_first_name'] ?? '');
    $ln  = trim($_POST['edit_last_name']  ?? '');
    $em  = trim($_POST['edit_email']      ?? '');
    $ph  = trim($_POST['edit_phone']      ?? '');

    $stmt = $conn->prepare(
        "UPDATE tblUser SET first_name=?, last_name=?, email=?, phone=? WHERE user_id=?"
    );
    $stmt->bind_param('ssssi', $fn, $ln, $em, $ph, $uid);
    if ($stmt->execute()) {
        $message = 'Customer updated successfully.';
    } else {
        $message = 'Update failed: ' . $conn->error;
        $msgType = 'danger';
    }
    $stmt->close();
}

// ── Fetch all users ───────────────────────────────
$usersResult = $conn->query("SELECT * FROM tblUser ORDER BY is_verified ASC, created_at DESC");
$users = [];
while ($row = $usersResult->fetch_assoc()) {
    $users[] = $row;
}

// Fetch user for editing if edit action
$editUser = null;
if ($action === 'edit' && $userId > 0) {
    $s = $conn->prepare("SELECT * FROM tblUser WHERE user_id = ?");
    $s->bind_param('i', $userId);
    $s->execute();
    $editUser = $s->get_result()->fetch_assoc();
    $s->close();
}

$conn->close();
$adminName = htmlspecialchars($_SESSION['admin_first_name'] . ' ' . $_SESSION['admin_last_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard – Pastimes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="user-bar">
    <span>⚙ Admin: <strong><?= $adminName ?></strong><span class="admin-tag">ADMIN</span></span>
    <div>
        <a href="../index.php">View Shop</a> &nbsp;|&nbsp;
        <a href="adminLogout.php">Logout</a>
    </div>
</div>

<nav class="navbar">
    <a class="navbar-brand" href="dashboard.php">Past<span>imes</span> Admin</a>
    <ul class="navbar-links">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="../index.php">Shop</a></li>
        <li><a href="adminLogout.php">Logout</a></li>
    </ul>
</nav>

<div class="container" style="padding-top:28px;">

    <?php if ($message): ?>
        <div class="alert alert-<?= $msgType ?>"><?= $message ?></div>
    <?php endif; ?>

    <!-- Stats row -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:28px;">
        <?php
        $total    = count($users);
        $pending  = count(array_filter($users, fn($u) => $u['is_verified'] == 0));
        $verified = $total - $pending;
        ?>
        <div class="card" style="margin:0;">
            <div class="card-body" style="text-align:center;">
                <div style="font-size:2rem;font-weight:700;color:var(--accent);"><?= $total ?></div>
                <div class="text-muted" style="font-size:0.85rem;">Total Users</div>
            </div>
        </div>
        <div class="card" style="margin:0;">
            <div class="card-body" style="text-align:center;">
                <div style="font-size:2rem;font-weight:700;color:var(--success);"><?= $verified ?></div>
                <div class="text-muted" style="font-size:0.85rem;">Verified</div>
            </div>
        </div>
        <div class="card" style="margin:0;">
            <div class="card-body" style="text-align:center;">
                <div style="font-size:2rem;font-weight:700;color:var(--danger);"><?= $pending ?></div>
                <div class="text-muted" style="font-size:0.85rem;">Pending Approval</div>
            </div>
        </div>
    </div>

    <!-- ── Add new customer ── -->
    <div class="card">
        <div class="card-header"><h2>➕ Add New Customer</h2></div>
        <div class="card-body">
            <form method="POST" action="dashboard.php" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;align-items:end;">
                <div class="form-group" style="margin:0;">
                    <label>First Name *</label>
                    <input type="text" name="first_name" class="form-control" required placeholder="First">
                </div>
                <div class="form-group" style="margin:0;">
                    <label>Last Name *</label>
                    <input type="text" name="last_name" class="form-control" required placeholder="Last">
                </div>
                <div class="form-group" style="margin:0;">
                    <label>Email *</label>
                    <input type="email" name="email" class="form-control" required placeholder="email@example.com">
                </div>
                <div class="form-group" style="margin:0;">
                    <label>Phone</label>
                    <input type="tel" name="phone" class="form-control" placeholder="082...">
                </div>
                <div class="form-group" style="margin:0;">
                    <label>Password *</label>
                    <input type="password" name="password" class="form-control" required minlength="4">
                </div>
                <div style="margin:0;">
                    <button type="submit" name="add_user" class="btn btn-success" style="width:100%;">Add Customer</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ── Edit customer (shown when edit action is triggered) ── -->
    <?php if ($editUser): ?>
    <div class="card">
        <div class="card-header"><h2>✏ Edit Customer: <?= htmlspecialchars($editUser['first_name'] . ' ' . $editUser['last_name']) ?></h2></div>
        <div class="card-body">
            <form method="POST" action="dashboard.php" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;align-items:end;">
                <input type="hidden" name="edit_user_id" value="<?= $editUser['user_id'] ?>">
                <div class="form-group" style="margin:0;">
                    <label>First Name</label>
                    <input type="text" name="edit_first_name" class="form-control" value="<?= htmlspecialchars($editUser['first_name']) ?>" required>
                </div>
                <div class="form-group" style="margin:0;">
                    <label>Last Name</label>
                    <input type="text" name="edit_last_name" class="form-control" value="<?= htmlspecialchars($editUser['last_name']) ?>" required>
                </div>
                <div class="form-group" style="margin:0;">
                    <label>Email</label>
                    <input type="email" name="edit_email" class="form-control" value="<?= htmlspecialchars($editUser['email']) ?>" required>
                </div>
                <div class="form-group" style="margin:0;">
                    <label>Phone</label>
                    <input type="tel" name="edit_phone" class="form-control" value="<?= htmlspecialchars($editUser['phone']) ?>">
                </div>
                <div style="margin:0;">
                    <button type="submit" name="update_user" class="btn btn-primary" style="width:100%;">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- ── All users table ── -->
    <div class="card">
        <div class="card-header"><h2>👥 All Registered Users</h2><p>Manage, verify, edit and delete accounts</p></div>
        <div class="card-body" style="padding:0;">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                        <tr style="<?= $u['is_verified'] == 0 ? 'background:#fff8e1;' : '' ?>">
                            <td><?= $u['user_id'] ?></td>
                            <td><strong><?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name']) ?></strong></td>
                            <td><?= htmlspecialchars($u['email']) ?></td>
                            <td><?= htmlspecialchars($u['phone'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($u['role']) ?></td>
                            <td>
                                <?php if ($u['is_verified']): ?>
                                    <span class="badge badge-good">✔ Verified</span>
                                <?php else: ?>
                                    <span class="badge badge-fair">⏳ Pending</span>
                                <?php endif; ?>
                            </td>
                            <td style="font-size:0.8rem;"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                            <td>
                                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                                    <?php if (!$u['is_verified']): ?>
                                        <a href="dashboard.php?action=verify&uid=<?= $u['user_id'] ?>"
                                           class="btn btn-success btn-sm">✔ Verify</a>
                                    <?php endif; ?>
                                    <a href="dashboard.php?action=edit&uid=<?= $u['user_id'] ?>"
                                       class="btn btn-secondary btn-sm">✏ Edit</a>
                                    <a href="dashboard.php?action=delete&uid=<?= $u['user_id'] ?>"
                                       class="btn btn-danger btn-sm"
                                       onclick="return confirm('Delete this user permanently?')">🗑 Delete</a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div><!-- /container -->

<footer>
    <p>&copy; <?= date('Y') ?> <span>Pastimes</span> – Admin Dashboard | ST10440743</p>
</footer>

</body>
</html>
