<?php
/**
 * register.php
 * -----------------------------------------------
 * New user registration.
 * - All fields required (HTML5 + server-side)
 * - Password hashed with MD5 before storing
 * - New registrations set to role='pending', is_verified=0
 * - Admin must verify before user can log in
 * Student : Nkuna Kuhlula  |  ST10440743
 * -----------------------------------------------
 */

session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once 'DBConn.php';

$error   = '';
$success = '';

// Sticky field values
$firstName = '';
$lastName  = '';
$email     = '';
$phone     = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Collect and sanitise
    $firstName = trim($_POST['first_name'] ?? '');
    $lastName  = trim($_POST['last_name']  ?? '');
    $email     = trim($_POST['email']      ?? '');
    $phone     = trim($_POST['phone']      ?? '');
    $password  = trim($_POST['password']   ?? '');
    $confirm   = trim($_POST['confirm']    ?? '');

    // ── Server-side validation ────────────────────
    if (empty($firstName) || empty($lastName) || empty($email) || empty($password) || empty($confirm)) {
        $error = 'All fields are required. Please fill in the complete form.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';

    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';

    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match. Please try again.';

    } else {
        // Check if email already exists
        $chk = $conn->prepare("SELECT user_id FROM tblUser WHERE email = ?");
        $chk->bind_param('s', $email);
        $chk->execute();
        $chk->store_result();

        if ($chk->num_rows > 0) {
            $error = 'An account with that email already exists. Please login.';
        } else {
            // Hash the password
            $hash = md5($password);

            // Insert new user as pending
            $ins = $conn->prepare(
                "INSERT INTO tblUser (first_name, last_name, email, password_hash, phone, role, is_verified)
                 VALUES (?, ?, ?, ?, ?, 'pending', 0)"
            );
            $ins->bind_param('sssss', $firstName, $lastName, $email, $hash, $phone);

            if ($ins->execute()) {
                $success = "Registration successful! Your account is <strong>pending approval</strong> by an administrator. 
                            You will be able to log in once verified.";
                // Reset sticky fields
                $firstName = $lastName = $email = $phone = '';
            } else {
                $error = 'Registration failed. Please try again.';
            }
            $ins->close();
        }
        $chk->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register – Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<nav class="navbar">
    <a class="navbar-brand" href="login.php">Past<span>imes</span></a>
    <ul class="navbar-links">
        <li><a href="login.php">Login</a></li>
        <li><a href="register.php">Register</a></li>
    </ul>
</nav>

<div class="auth-wrapper">
    <div class="auth-box" style="max-width:500px;">

        <div class="auth-header">
            <h2>Create Account</h2>
            <p>Join Pastimes – pre-owned branded fashion</p>
        </div>

        <div class="auth-body">

            <?php if ($error):   ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
            <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>

            <?php if (!$success): ?>
            <form method="POST" action="register.php">

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                    <div class="form-group">
                        <label for="first_name">First Name</label>
                        <input type="text" id="first_name" name="first_name" class="form-control"
                               placeholder="John"
                               value="<?= htmlspecialchars($firstName) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last Name</label>
                        <input type="text" id="last_name" name="last_name" class="form-control"
                               placeholder="Doe"
                               value="<?= htmlspecialchars($lastName) ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" class="form-control"
                           placeholder="john@example.com"
                           value="<?= htmlspecialchars($email) ?>" required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" class="form-control"
                           placeholder="082 000 0000"
                           value="<?= htmlspecialchars($phone) ?>">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control"
                           placeholder="At least 6 characters" required minlength="6">
                </div>

                <div class="form-group">
                    <label for="confirm">Confirm Password</label>
                    <input type="password" id="confirm" name="confirm" class="form-control"
                           placeholder="Repeat password" required minlength="6">
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;">
                    Create My Account
                </button>

            </form>
            <?php endif; ?>

            <hr>
            <p class="text-center text-muted" style="font-size:0.88rem;">
                Already have an account?
                <a href="login.php" style="color:var(--accent);font-weight:500;">Sign in</a>
            </p>

        </div>
    </div>
</div>

<footer>
    <p>&copy; <?= date('Y') ?> <span>Pastimes</span> – Pre-owned Branded Clothing | ST10440743</p>
</footer>

</body>
</html>
