<?php
/**
 * history.php  –  Order History
 * Shows all past orders with totals at the bottom of the page.
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
if(!isset($_SESSION['user_id'])){ header('Location: login.php'); exit; }

require_once 'DBConn.php';

$userId   = (int)$_SESSION['user_id'];
$fullName = htmlspecialchars($_SESSION['first_name'].' '.$_SESSION['last_name']);

// Fetch all orders for this user
$ordersStmt = $conn->prepare(
    "SELECT o.order_id, o.order_ref, o.session_ref, o.total_amount, o.status, o.created_at
     FROM tblOrder o WHERE o.user_id = ? ORDER BY o.created_at DESC"
);
$ordersStmt->bind_param('i', $userId);
$ordersStmt->execute();
$ordersResult = $ordersStmt->get_result();

$orders    = [];
$grandTotal = 0;

while($order = $ordersResult->fetch_assoc()){
    // Fetch order lines for each order
    $lineStmt = $conn->prepare(
        "SELECT ol.quantity, ol.unit_price, c.title, c.brand, c.image_filename
         FROM tblOrderLine ol
         JOIN tblClothes c ON ol.item_id = c.item_id
         WHERE ol.order_id = ?"
    );
    $lineStmt->bind_param('i', $order['order_id']);
    $lineStmt->execute();
    $lineResult = $lineStmt->get_result();
    $lines = [];
    while($line = $lineResult->fetch_assoc()) $lines[] = $line;
    $lineStmt->close();

    $order['lines'] = $lines;
    $orders[] = $order;
    $grandTotal += (float)$order['total_amount'];
}
$ordersStmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Order History – Pastimes</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="user-bar">
  <span>👤 User <strong><?=$fullName?></strong> is logged in</span>
  <a href="logout.php">Logout</a>
</div>

<nav class="navbar">
  <a class="navbar-brand" href="index.php">Pastimes</a>
  <ul class="navbar-links">
    <li><a href="index.php">Home</a></li>
    <li><a href="shop.php">Shop</a></li>
    <li><a href="cart.php">🛒 Cart</a></li>
    <li><a href="history.php" class="active">Orders</a></li>
    <li><a href="logout.php" class="btn btn-accent btn-sm">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:40px;padding-bottom:80px">

  <div style="margin-bottom:32px">
    <h2 class="section-title">📦 My Order History</h2>
    <p style="color:var(--muted)">All purchases made on Pastimes</p>
  </div>

  <?php if(empty($orders)): ?>
    <div class="card" style="text-align:center;padding:48px">
      <div style="font-size:3rem;margin-bottom:16px">📭</div>
      <h3 style="color:var(--white);margin-bottom:8px">No orders yet</h3>
      <p style="color:var(--muted);margin-bottom:24px">Head to the shop and grab something great.</p>
      <a href="shop.php" class="btn btn-primary">Browse Shop</a>
    </div>
  <?php else: ?>

    <?php foreach($orders as $order): ?>
    <div class="card" style="margin-bottom:24px">
      <!-- Order Header -->
      <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div>
          <h2 style="font-size:.95rem">Order Ref: <code style="color:var(--accent);font-size:1rem"><?=htmlspecialchars($order['order_ref'])?></code></h2>
          <p>Session: <code style="font-size:.75rem;color:var(--muted)"><?=htmlspecialchars(substr($order['session_ref'],0,24))?>...</code> &nbsp;·&nbsp; <?=date('d M Y H:i',strtotime($order['created_at']))?></p>
        </div>
        <div style="text-align:right">
          <div style="font-size:1.3rem;font-weight:800;color:var(--accent)">R <?=number_format($order['total_amount'],2)?></div>
          <span class="role-tag <?=$order['status']==='placed'?'role-seller':'role-customer'?>"><?=ucfirst($order['status'])?></span>
        </div>
      </div>
      <!-- Order Lines -->
      <div class="card-body" style="padding:0">
        <table>
          <thead><tr><th>Image</th><th>Item</th><th>Brand</th><th>Qty</th><th>Unit Price</th><th>Subtotal</th></tr></thead>
          <tbody>
            <?php foreach($order['lines'] as $line): ?>
            <tr>
              <td><img src="images/<?=htmlspecialchars($line['image_filename'])?>" style="width:50px;height:50px;object-fit:cover;border-radius:8px" onerror="this.src='images/item1.jpg'"></td>
              <td><?=htmlspecialchars($line['title'])?></td>
              <td><?=htmlspecialchars($line['brand'])?></td>
              <td><?=$line['quantity']?></td>
              <td>R <?=number_format($line['unit_price'],2)?></td>
              <td><strong style="color:var(--accent)">R <?=number_format($line['unit_price']*$line['quantity'],2)?></strong></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endforeach; ?>

    <!-- Grand Total at bottom of page (rubric requirement) -->
    <div style="background:linear-gradient(135deg,rgba(108,99,255,0.15),rgba(255,101,132,0.1));border:1px solid rgba(108,99,255,0.3);border-radius:var(--radius);padding:28px 32px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px">
      <div>
        <div style="font-size:.8rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">Total Spent on Pastimes</div>
        <div style="font-size:.9rem;color:var(--muted)"><?=count($orders)?> order<?=count($orders)!==1?'s':''?> completed</div>
      </div>
      <div style="font-size:2.2rem;font-weight:900;background:linear-gradient(135deg,var(--primary),var(--accent));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text">
        R <?=number_format($grandTotal,2)?>
      </div>
    </div>

  <?php endif; ?>
</div>

<footer>
  <p>© <?=date('Y')?> <span class="brand">Pastimes</span> &nbsp;|&nbsp; ST10440743</p>
</footer>
</body>
</html>
