<?php
/**
 * cart.php  –  Shopping Cart Page
 * Edit quantities, remove items, continue shopping,
 * empty cart, proceed to checkout.
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
if(!isset($_SESSION['user_id'])){ header('Location: login.php'); exit; }

require_once 'DBConn.php';
require_once 'classes/Cart.php';

$cart = new Cart();
$msg  = '';

if($_SERVER['REQUEST_METHOD']==='POST'){
    $msg = $cart->ProcessInput($conn);
}

$conn->close();
$cartCount = $cart->GetCount();
$fullName  = htmlspecialchars($_SESSION['first_name'].' '.$_SESSION['last_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Cart – Pastimes</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="user-bar">
  <span>👤 User <strong><?=$fullName?></strong> is logged in</span>
  <a href="logout.php">Logout</a>
</div>

<nav class="navbar">
  <a class="navbar-brand" href="index.php">Pastimes</a>
  <ul class="navbar-links">
    <li><a href="index.php">Home</a></li>
    <li><a href="shop.php">Shop</a></li>
    <li><a href="cart.php" class="active">🛒 Cart <span class="cart-badge"><?=$cartCount?></span></a></li>
    <li><a href="history.php">Orders</a></li>
    <li><a href="logout.php" class="btn btn-accent btn-sm">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:40px;padding-bottom:80px">

  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px;flex-wrap:wrap;gap:12px">
    <div>
      <h2 class="section-title" style="margin-bottom:4px">🛒 Your Shopping Cart</h2>
      <p style="color:var(--muted);font-size:.9rem"><?=$cartCount?> item<?=$cartCount!==1?'s':''?> · Total: <strong style="color:var(--accent)">R <?=number_format($cart->GetTotal(),2)?></strong></p>
    </div>
    <!-- Continue Shopping button (cart stays intact) -->
    <a href="shop.php" class="btn btn-ghost">← Continue Shopping</a>
  </div>

  <?php if($msg): ?>
    <div class="alert alert-success"><?=$msg?></div>
  <?php endif; ?>

  <!-- ShowCart via Cart class -->
  <?= $cart->ShowCart() ?>

  <?php if($cartCount > 0): ?>
  <div style="margin-top:24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
    <form method="POST">
      <button type="submit" name="empty_cart" class="btn btn-danger" onclick="return confirm('Clear your entire cart?')">🗑 Empty Cart</button>
    </form>
    <div style="display:flex;gap:12px;flex-wrap:wrap">
      <a href="shop.php" class="btn btn-ghost">← Continue Shopping</a>
      <a href="checkout.php" class="btn btn-primary btn-lg">Checkout →</a>
    </div>
  </div>
  <?php endif; ?>

</div>

<footer>
  <p>© <?=date('Y')?> <span class="brand">Pastimes</span> &nbsp;|&nbsp; ST10440743</p>
</footer>
</body>
</html>
