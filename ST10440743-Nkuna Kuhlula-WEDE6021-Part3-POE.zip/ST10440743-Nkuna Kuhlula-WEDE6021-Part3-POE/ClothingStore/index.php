<?php
/**
 * index.php  –  Pastimes Startup/Landing Page
 * Clearly states type of eShop and goals, styled with CSS.
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
$loggedIn  = isset($_SESSION['user_id']);
$cartCount = isset($_SESSION['cart_items']) ? count($_SESSION['cart_items']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Pastimes – Pre-Owned Branded Fashion</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .feature-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:24px;margin-top:48px}
    .feature-card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:32px 28px;text-align:center;transition:var(--transition)}
    .feature-card:hover{border-color:rgba(108,99,255,0.4);transform:translateY(-4px)}
    .feature-icon{font-size:2.5rem;margin-bottom:16px}
    .feature-card h3{font-size:1rem;font-weight:700;color:var(--white);margin-bottom:8px}
    .feature-card p{font-size:.85rem;color:var(--muted);line-height:1.7}
    .steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:24px;margin-top:40px}
    .step{display:flex;flex-direction:column;align-items:center;text-align:center;gap:12px}
    .step-num{width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;font-size:1.1rem;font-weight:800;color:#fff}
    .step h4{font-size:.9rem;font-weight:700;color:var(--white)}
    .step p{font-size:.82rem;color:var(--muted)}
    .brands{display:flex;gap:32px;justify-content:center;flex-wrap:wrap;margin-top:24px;opacity:.4}
    .brands span{font-size:1rem;font-weight:800;color:var(--text);letter-spacing:2px;text-transform:uppercase}
  </style>
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="index.php">Pastimes</a>
  <ul class="navbar-links">
    <li><a href="index.php" class="active">Home</a></li>
    <li><a href="shop.php">Shop</a></li>
    <?php if($loggedIn): ?>
      <li><a href="cart.php">Cart <span class="cart-badge"><?=$cartCount?></span></a></li>
      <li><a href="history.php">Orders</a></li>
      <li><a href="messages.php">Messages</a></li>
      <li><a href="seller/requestItem.php">Sell</a></li>
      <li><a href="logout.php" class="btn btn-accent btn-sm">Logout</a></li>
    <?php else: ?>
      <li><a href="login.php">Login</a></li>
      <li><a href="register.php" class="btn btn-primary btn-sm">Get Started</a></li>
    <?php endif; ?>
  </ul>
</nav>

<?php if($loggedIn): ?>
<div class="user-bar">
  <span>👋 Welcome back, <strong><?=htmlspecialchars($_SESSION['first_name'].' '.$_SESSION['last_name'])?></strong></span>
  <a href="shop.php">Browse the shop →</a>
</div>
<?php endif; ?>

<!-- Hero -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-grid"></div>
  <div class="hero-content">
    <div class="hero-tag">🇿🇦 South Africa's Pre-Owned Fashion Marketplace</div>
    <h1>Buy &amp; Sell <span class="grad">Branded</span><br>Fashion. Sustainably.</h1>
    <p>Pastimes is a curated second-hand clothing marketplace connecting buyers, sellers and fashion lovers across South Africa. Designer pieces at honest prices.</p>
    <div class="hero-actions">
      <a href="shop.php" class="btn btn-primary btn-lg">🛍 Browse the Shop</a>
      <a href="register.php" class="btn btn-ghost btn-lg">Start Selling →</a>
    </div>
  </div>
  <div class="hero-stats">
    <div><div class="stat-num">12+</div><div class="stat-lbl">Listed Items</div></div>
    <div><div class="stat-num">10+</div><div class="stat-lbl">Members</div></div>
    <div><div class="stat-num">100%</div><div class="stat-lbl">Authentic</div></div>
    <div><div class="stat-num">R0</div><div class="stat-lbl">Seller Fees</div></div>
  </div>
</section>

<!-- What We Do -->
<section class="section" style="background:var(--bg2);border-top:1px solid var(--border);border-bottom:1px solid var(--border);">
  <div class="container">
    <div style="text-align:center">
      <h2 class="section-title">What is Pastimes?</h2>
      <p class="section-sub">A fully online pre-owned branded clothing eShop — built to make second-hand fashion easy, safe and stylish for South Africans.</p>
    </div>
    <div class="feature-grid">
      <div class="feature-card"><div class="feature-icon">🛒</div><h3>Smart Shopping Cart</h3><p>Add items, edit quantities and continue shopping. Your cart stays intact throughout your session.</p></div>
      <div class="feature-card"><div class="feature-icon">🔐</div><h3>Secure Accounts</h3><p>Every password is MD5-hashed. New accounts require admin verification before login access.</p></div>
      <div class="feature-card"><div class="feature-icon">👗</div><h3>Seller Listings</h3><p>Submit items with photos, brand and description. Admin reviews and lists within 24 hours.</p></div>
      <div class="feature-card"><div class="feature-icon">⚙️</div><h3>Admin Control</h3><p>A full admin dashboard manages users, clothing stock, seller requests and communications.</p></div>
      <div class="feature-card"><div class="feature-icon">📦</div><h3>Order Tracking</h3><p>Every checkout generates a unique order reference and session ID with full purchase history.</p></div>
      <div class="feature-card"><div class="feature-icon">💬</div><h3>Direct Messaging</h3><p>Buyers and sellers communicate directly through the platform. Admins ensure smooth delivery.</p></div>
    </div>
  </div>
</section>

<!-- How It Works -->
<section class="section">
  <div class="container">
    <div style="text-align:center">
      <h2 class="section-title">How It Works</h2>
      <p class="section-sub">Four simple steps to your next great find</p>
    </div>
    <div class="steps">
      <div class="step"><div class="step-num">1</div><h4>Create Account</h4><p>Register as buyer or seller. Admin verifies before full access.</p></div>
      <div class="step"><div class="step-num">2</div><h4>Browse &amp; Shop</h4><p>Explore curated listings. Filter by brand, size and condition.</p></div>
      <div class="step"><div class="step-num">3</div><h4>Checkout Securely</h4><p>Add to cart, review order and get a unique reference instantly.</p></div>
      <div class="step"><div class="step-num">4</div><h4>Sell Your Pieces</h4><p>Submit items with photos. Once approved they go live immediately.</p></div>
    </div>
  </div>
</section>

<!-- Brands -->
<section class="section" style="background:var(--bg2);border-top:1px solid var(--border);padding:48px 0;">
  <div class="container" style="text-align:center">
    <p class="section-sub" style="margin-bottom:16px">Brands you'll find on Pastimes</p>
    <div class="brands">
      <span>Levis</span><span>Nike</span><span>Adidas</span><span>Gucci</span><span>Puma</span><span>Supreme</span><span>Tommy</span><span>Zara</span>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="section" style="text-align:center">
  <div class="container">
    <h2 class="section-title">Ready to find your next favourite piece?</h2>
    <p class="section-sub">Join South Africans buying and selling fashion sustainably.</p>
    <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap">
      <a href="shop.php" class="btn btn-primary btn-lg">Shop Now</a>
      <?php if(!$loggedIn):?><a href="register.php" class="btn btn-ghost btn-lg">Create Account</a><?php endif;?>
    </div>
  </div>
</section>

<footer>
  <p>© <?=date('Y')?> <span class="brand">Pastimes</span> – Pre-Owned Branded Clothing Marketplace &nbsp;|&nbsp; ST10440743 &nbsp;|&nbsp; WEDE6020</p>
</footer>
</body>
</html>
