<?php
/**
 * classes/Cart.php
 * -----------------------------------------------
 * Shopping Cart Class for Pastimes
 * Member functions: AddItem, RemoveItem, Checkout,
 * EmptyCart, Login, ProcessInput, ShowCart,
 * UpdateQuantity, GetTotal, GetCount
 * Student : Nkuna Kuhlula  |  ST10440743
 * -----------------------------------------------
 */

class Cart
{
    // ── Private cart items array ──────────────────
    private array $items = [];

    // ── Constructor: restore cart from session ────
    public function __construct()
    {
        if (isset($_SESSION['cart_items']) && is_array($_SESSION['cart_items'])) {
            $this->items = $_SESSION['cart_items'];
        }
    }

    // ── Save cart back to session ─────────────────
    private function SaveToSession(): void
    {
        $_SESSION['cart_items'] = $this->items;
    }

    /**
     * AddItem()
     * Adds an item to the cart.
     * If item already exists, quantity increments (does NOT add new row).
     *
     * @param array $item  Associative array from tblClothes
     * @return bool
     */
    public function AddItem(array $item): bool
    {
        $id = (int) $item['item_id'];

        if (isset($this->items[$id])) {
            // Item exists – increase quantity
            $this->items[$id]['quantity']++;
        } else {
            // New item – add to cart
            $this->items[$id] = [
                'item_id'        => $id,
                'title'          => $item['title'],
                'brand'          => $item['brand'],
                'size'           => $item['size'],
                'sell_price'     => (float) $item['sell_price'],
                'image_filename' => $item['image_filename'],
                'quantity'       => 1,
                'stock'          => (int) $item['quantity'],
            ];
        }

        $this->SaveToSession();
        return true;
    }

    /**
     * RemoveItem()
     * Removes an item completely from the cart by item_id.
     *
     * @param int $itemId
     * @return bool
     */
    public function RemoveItem(int $itemId): bool
    {
        if (isset($this->items[$itemId])) {
            unset($this->items[$itemId]);
            $this->SaveToSession();
            return true;
        }
        return false;
    }

    /**
     * UpdateQuantity()
     * Changes the quantity of a cart item.
     * Removes item if quantity drops to 0.
     *
     * @param int $itemId
     * @param int $qty
     * @return bool
     */
    public function UpdateQuantity(int $itemId, int $qty): bool
    {
        if (!isset($this->items[$itemId])) {
            return false;
        }

        if ($qty <= 0) {
            return $this->RemoveItem($itemId);
        }

        $this->items[$itemId]['quantity'] = $qty;
        $this->SaveToSession();
        return true;
    }

    /**
     * GetTotal()
     * Returns the total value of all cart items.
     *
     * @return float
     */
    public function GetTotal(): float
    {
        $total = 0.0;
        foreach ($this->items as $item) {
            $total += $item['sell_price'] * $item['quantity'];
        }
        return $total;
    }

    /**
     * GetCount()
     * Returns total number of item lines in the cart.
     *
     * @return int
     */
    public function GetCount(): int
    {
        return count($this->items);
    }

    /**
     * GetItems()
     * Returns the full cart items array.
     *
     * @return array
     */
    public function GetItems(): array
    {
        return $this->items;
    }

    /**
     * ShowCart()
     * Renders the cart contents as an HTML table.
     * Returns the HTML string.
     *
     * @return string
     */
    public function ShowCart(): string
    {
        if (empty($this->items)) {
            return '<div class="alert alert-info">Your cart is empty. 
                    <a href="shop.php">Continue Shopping →</a></div>';
        }

        $html  = '<div class="table-wrapper">';
        $html .= '<table>';
        $html .= '<thead><tr>
                    <th>Image</th>
                    <th>Item</th>
                    <th>Brand</th>
                    <th>Size</th>
                    <th>Unit Price</th>
                    <th>Qty</th>
                    <th>Subtotal</th>
                    <th>Remove</th>
                  </tr></thead>';
        $html .= '<tbody>';

        foreach ($this->items as $id => $item) {
            $sub   = $item['sell_price'] * $item['quantity'];
            $img   = htmlspecialchars($item['image_filename']);
            $title = htmlspecialchars($item['title']);
            $brand = htmlspecialchars($item['brand']);
            $size  = htmlspecialchars($item['size']);
            $price = number_format($item['sell_price'], 2);
            $subFmt = number_format($sub, 2);

            $html .= "<tr>
                <td><img src='images/{$img}' style='width:60px;height:60px;object-fit:cover;border-radius:8px;' onerror=\"this.src='images/item1.jpg'\"></td>
                <td><strong>{$title}</strong></td>
                <td>{$brand}</td>
                <td>{$size}</td>
                <td>R {$price}</td>
                <td>
                    <form method='POST' action='cart.php' style='display:flex;align-items:center;gap:6px;'>
                        <input type='hidden' name='item_id' value='{$id}'>
                        <input type='number' name='qty' value='{$item['quantity']}' min='1' max='{$item['stock']}'
                               style='width:60px;padding:4px 8px;border:1.5px solid #e0e0e0;border-radius:6px;font-family:inherit;'>
                        <button type='submit' name='update_qty' class='btn btn-secondary btn-sm'>↻</button>
                    </form>
                </td>
                <td><strong style='color:var(--accent);'>R {$subFmt}</strong></td>
                <td>
                    <form method='POST' action='cart.php'>
                        <input type='hidden' name='item_id' value='{$id}'>
                        <button type='submit' name='remove_item' class='btn btn-danger btn-sm'>✕</button>
                    </form>
                </td>
              </tr>";
        }

        $total  = number_format($this->GetTotal(), 2);
        $html  .= "</tbody>";
        $html  .= "<tfoot><tr>
                    <td colspan='6' style='text-align:right;padding:16px;font-weight:700;font-size:1rem;'>Order Total:</td>
                    <td style='padding:16px;font-weight:700;font-size:1.2rem;color:var(--accent);'>R {$total}</td>
                    <td></td>
                  </tr></tfoot>";
        $html  .= '</table></div>';

        return $html;
    }

    /**
     * EmptyCart()
     * Clears all items from the cart and session.
     *
     * @return void
     */
    public function EmptyCart(): void
    {
        $this->items = [];
        unset($_SESSION['cart_items']);
    }

    /**
     * Login()
     * Validates whether the current session has an
     * authenticated user. Redirects if not.
     *
     * @return bool
     */
    public function Login(): bool
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: login.php');
            exit;
        }
        return true;
    }

    /**
     * ProcessInput()
     * Handles all POST actions for the cart:
     * add, remove, update_qty, empty_cart.
     * Requires a MySQLi connection for AddItem lookups.
     *
     * @param mysqli $conn
     * @return string  feedback message
     */
    public function ProcessInput(mysqli $conn): string
    {
        $msg = '';

        // ── Add item ──────────────────────────────
        if (isset($_POST['add_to_cart'])) {
            $itemId = (int) ($_POST['item_id'] ?? 0);
            $stmt   = $conn->prepare(
                "SELECT * FROM tblClothes WHERE item_id = ? AND status = 'available' AND quantity > 0"
            );
            $stmt->bind_param('i', $itemId);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $item = $result->fetch_assoc();
                $this->AddItem($item);
                $msg = "✔ <strong>" . htmlspecialchars($item['title']) . "</strong> added to cart.";
            }
            $stmt->close();
        }

        // ── Remove item ───────────────────────────
        if (isset($_POST['remove_item'])) {
            $itemId = (int) ($_POST['item_id'] ?? 0);
            $this->RemoveItem($itemId);
            $msg = "Item removed from cart.";
        }

        // ── Update quantity ───────────────────────
        if (isset($_POST['update_qty'])) {
            $itemId = (int) ($_POST['item_id'] ?? 0);
            $qty    = (int) ($_POST['qty']     ?? 1);
            $this->UpdateQuantity($itemId, $qty);
            $msg = "Quantity updated.";
        }

        // ── Empty cart ────────────────────────────
        if (isset($_POST['empty_cart'])) {
            $this->EmptyCart();
            $msg = "Cart cleared.";
        }

        return $msg;
    }

    /**
     * Checkout()
     * Saves order + order lines to DB, decrements stock,
     * returns order reference and session ID.
     *
     * @param mysqli $conn
     * @param int    $userId
     * @return array ['order_ref' => string, 'session_ref' => string, 'order_id' => int]
     */
    public function Checkout(mysqli $conn, int $userId): array
    {
        if (empty($this->items)) {
            return [];
        }

        // Generate references
        $orderRef   = 'ORD-' . strtoupper(substr(uniqid(), -6));
        $sessionRef = session_id();
        $total      = $this->GetTotal();

        // Insert into tblOrder
        $stmt = $conn->prepare(
            "INSERT INTO tblOrder (user_id, session_ref, order_ref, total_amount, status)
             VALUES (?, ?, ?, ?, 'placed')"
        );
        $stmt->bind_param('issd', $userId, $sessionRef, $orderRef, $total);
        $stmt->execute();
        $orderId = $conn->insert_id;
        $stmt->close();

        // Insert order lines and decrement stock
        $lineStmt = $conn->prepare(
            "INSERT INTO tblOrderLine (order_id, item_id, quantity, unit_price) VALUES (?, ?, ?, ?)"
        );
        $stockStmt = $conn->prepare(
            "UPDATE tblClothes SET quantity = quantity - ? WHERE item_id = ? AND quantity >= ?"
        );

        foreach ($this->items as $item) {
            $itemId = $item['item_id'];
            $qty    = $item['quantity'];
            $price  = $item['sell_price'];

            $lineStmt->bind_param('iiid', $orderId, $itemId, $qty, $price);
            $lineStmt->execute();

            $stockStmt->bind_param('iii', $qty, $itemId, $qty);
            $stockStmt->execute();
        }

        $lineStmt->close();
        $stockStmt->close();

        // Clear cart after checkout
        $this->EmptyCart();

        return [
            'order_ref'   => $orderRef,
            'session_ref' => $sessionRef,
            'order_id'    => $orderId,
            'total'       => $total,
        ];
    }
}
?>
