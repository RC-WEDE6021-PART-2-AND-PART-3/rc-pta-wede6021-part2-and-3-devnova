<?php
/**
 * seller/requestItem.php
 * Seller sends a request to sell clothes.
 * Captures: title, brand, description, image, price, size, condition.
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
if(!isset($_SESSION['user_id'])){ header('Location: ../login.php'); exit; }

require_once '../DBConn.php';

$userId   = (int)$_SESSION['user_id'];
$fullName = htmlspecialchars($_SESSION['first_name'].' '.$_SESSION['last_name']);
$msg = ''; $err = '';

// Fetch my requests
$myReqs = $conn->prepare("SELECT * FROM tblSellerRequest WHERE user_id=? ORDER BY created_at DESC");
$myReqs->bind_param('i',$userId); $myReqs->execute();
$myRequests = $myReqs->get_result()->fetch_all(MYSQLI_ASSOC);
$myReqs->close();

if($_SERVER['REQUEST_METHOD']==='POST'){
    $title     = trim($_POST['title']     ?? '');
    $brand     = trim($_POST['brand']     ?? '');
    $desc      = trim($_POST['description']?? '');
    $price     = (float)($_POST['sell_price']?? 0);
    $size      = trim($_POST['size']      ?? '');
    $condition = trim($_POST['item_condition']?? 'Good');
    $imgFile   = '';

    if(!$title||!$brand||!$desc||!$price||!$size){
        $err = 'Please fill in all required fields.';
    } else {
        // Handle image upload
        if(isset($_FILES['image']) && $_FILES['image']['error']===0){
            $ext   = strtolower(pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','gif','webp'];
            if(in_array($ext,$allowed)){
                $imgFile = 'upload_'.time().'.'.$ext;
                $dest    = __DIR__.'/../uploads/'.$imgFile;
                if(!move_uploaded_file($_FILES['image']['tmp_name'],$dest)){
                    $imgFile = ''; // upload failed silently
                }
            }
        }

        $stmt = $conn->prepare(
            "INSERT INTO tblSellerRequest(user_id,title,brand,description,sell_price,size,item_condition,image_filename,status)
             VALUES(?,?,?,?,?,?,?,?,'pending')"
        );
        $stmt->bind_param('isssdsss',$userId,$title,$brand,$desc,$price,$size,$condition,$imgFile);
        if($stmt->execute()){
            $msg = "Your item <strong>$title</strong> has been submitted for review. Admin will approve it soon.";
            // Refresh list
            $myReqs2 = $conn->prepare("SELECT * FROM tblSellerRequest WHERE user_id=? ORDER BY created_at DESC");
            $myReqs2->bind_param('i',$userId); $myReqs2->execute();
            $myRequests = $myReqs2->get_result()->fetch_all(MYSQLI_ASSOC);
            $myReqs2->close();
        } else { $err = 'Submission failed. Please try again.'; }
        $stmt->close();
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Sell on Pastimes</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="user-bar">
  <span>👤 <strong><?=$fullName?></strong></span>
  <div><a href="../shop.php">Shop</a> &nbsp;|&nbsp; <a href="../logout.php">Logout</a></div>
</div>
<nav class="navbar">
  <a class="navbar-brand" href="../index.php">Pastimes</a>
  <ul class="navbar-links">
    <li><a href="../shop.php">Shop</a></li>
    <li><a href="../cart.php">Cart</a></li>
    <li><a href="requestItem.php" class="active">Sell</a></li>
    <li><a href="../logout.php" class="btn btn-accent btn-sm">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:40px;padding-bottom:80px">
  <h2 class="section-title" style="margin-bottom:8px">👗 Sell Your Clothes</h2>
  <p style="color:var(--muted);margin-bottom:32px">Submit an item for review. Our admin team will list it within 24 hours.</p>

  <?php if($msg):?><div class="alert alert-success"><?=$msg?></div><?php endif;?>
  <?php if($err):?><div class="alert alert-danger"><?=$err?></div><?php endif;?>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:32px;align-items:start">
    <!-- Submission Form -->
    <div class="card">
      <div class="card-header"><h2>New Item Request</h2><p>All fields marked * are required</p></div>
      <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
          <div class="form-group"><label>Item Title *</label><input type="text" name="title" class="form-control" placeholder='e.g. Nike Air Force 1 Low' required></div>
          <div class="form-group"><label>Brand *</label><input type="text" name="brand" class="form-control" placeholder="e.g. Nike" required></div>
          <div class="form-group"><label>Description *</label><textarea name="description" class="form-control" rows="4" placeholder="Describe the item, its condition and any defects..." required style="resize:vertical"></textarea></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
            <div class="form-group"><label>Selling Price (R) *</label><input type="number" name="sell_price" class="form-control" min="1" step="0.01" placeholder="0.00" required></div>
            <div class="form-group"><label>Size *</label><input type="text" name="size" class="form-control" placeholder="e.g. M, L, 9" required></div>
          </div>
          <div class="form-group">
            <label>Condition</label>
            <select name="item_condition" class="form-control">
              <option value="Excellent">Excellent</option>
              <option value="Good" selected>Good</option>
              <option value="Fair">Fair</option>
            </select>
          </div>
          <div class="form-group">
            <label>Item Photo</label>
            <input type="file" name="image" class="form-control" accept="image/*">
            <div style="font-size:.78rem;color:var(--muted);margin-top:6px">JPG, PNG or WebP. Max 5MB.</div>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%">📤 Submit for Review</button>
        </form>
      </div>
    </div>

    <!-- My Requests -->
    <div class="card">
      <div class="card-header"><h2>My Submissions</h2><p><?=count($myRequests)?> item<?=count($myRequests)!==1?'s':''?> submitted</p></div>
      <div class="card-body" style="padding:0;max-height:600px;overflow-y:auto">
        <?php if(empty($myRequests)):?>
          <div style="padding:32px;text-align:center;color:var(--muted)">No submissions yet</div>
        <?php else: foreach($myRequests as $r):?>
        <div style="padding:16px 20px;border-bottom:1px solid var(--border)">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px">
            <strong style="color:var(--white)"><?=htmlspecialchars($r['title'])?></strong>
            <span class="role-tag <?=$r['status']==='approved'?'role-customer':($r['status']==='rejected'?'role-admin':'role-seller')?>"><?=ucfirst($r['status'])?></span>
          </div>
          <div style="font-size:.82rem;color:var(--muted)">
            <?=htmlspecialchars($r['brand'])?> · Size <?=htmlspecialchars($r['size'])?> · R <?=number_format($r['sell_price'],2)?>
          </div>
          <div style="font-size:.78rem;color:var(--muted);margin-top:4px"><?=date('d M Y',strtotime($r['created_at']))?></div>
        </div>
        <?php endforeach; endif;?>
      </div>
    </div>
  </div>
</div>
<footer><p>© <?=date('Y')?> <span class="brand">Pastimes</span> &nbsp;|&nbsp; ST10440743</p></footer>
</body>
</html>
