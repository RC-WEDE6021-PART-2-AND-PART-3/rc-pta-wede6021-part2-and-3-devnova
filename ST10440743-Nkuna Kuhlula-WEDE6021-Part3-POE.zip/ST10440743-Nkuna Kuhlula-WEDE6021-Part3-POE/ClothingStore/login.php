<?php
/**
 * login.php  –  Customer Login
 * - Hash comparison against tblUser (MD5)
 * - Sticky form on wrong password
 * - "User John Doe is logged in" on success
 * - HTML5 validation on all fields
 * - Associative fetch in function
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
if(isset($_SESSION['user_id'])){ header('Location: index.php'); exit; }

require_once 'DBConn.php';

$error = '';
$email = '';

/**
 * fetchUserByEmail()
 * Fetches a user record as associative array from tblUser.
 * @param mysqli $conn
 * @param string $email
 * @return array|null
 */
function fetchUserByEmail(mysqli $conn, string $email): ?array {
    $stmt = $conn->prepare(
        "SELECT user_id,first_name,last_name,email,password_hash,role,is_verified
         FROM tblUser WHERE email = ?"
    );
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user   = $result->num_rows === 1 ? $result->fetch_assoc() : null;
    $stmt->close();
    return $user;
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if(empty($email) || empty($password)){
        $error = 'Please fill in all fields.';
    } else {
        $user = fetchUserByEmail($conn, $email);

        if($user){
            if(md5($password) === $user['password_hash']){
                if($user['is_verified'] == 0){
                    $error = '⏳ Your account is pending administrator verification. Please wait for approval before logging in.';
                } else {
                    $_SESSION['user_id']    = $user['user_id'];
                    $_SESSION['first_name'] = $user['first_name'];
                    $_SESSION['last_name']  = $user['last_name'];
                    $_SESSION['role']       = $user['role'];
                    $_SESSION['email']      = $user['email'];
                    header('Location: index.php');
                    exit;
                }
            } else {
                // Wrong password – sticky form (email value retained)
                $error = '❌ Incorrect password. Please try again.';
            }
        } else {
            $error = '❌ No account found with that email. Please register.';
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Login – Pastimes</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    body { background: radial-gradient(ellipse 80% 60% at 50% -10%, rgba(108,99,255,0.2) 0%, transparent 60%), var(--bg); }
    .auth-box { background:var(--card); border:1px solid var(--border); border-radius:var(--radius); box-shadow:0 24px 64px rgba(0,0,0,0.5); }
    .auth-logo { text-align:center; padding:36px 32px 0; }
    .auth-logo .brand-name { font-size:2rem; font-weight:900; background:linear-gradient(135deg,var(--primary),var(--accent)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
    .auth-logo p { color:var(--muted); font-size:.875rem; margin-top:4px; }
    .auth-body { padding:28px 32px 36px; }
    .divider-text { display:flex; align-items:center; gap:12px; color:var(--muted); font-size:.8rem; margin:20px 0; }
    .divider-text::before,.divider-text::after { content:''; flex:1; height:1px; background:var(--border); }
  </style>
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="index.php">Pastimes</a>
  <ul class="navbar-links">
    <li><a href="login.php" class="active">Login</a></li>
    <li><a href="register.php" class="btn btn-primary btn-sm">Register</a></li>
  </ul>
</nav>

<div class="auth-wrapper">
  <div class="auth-box" style="width:100%;max-width:420px;">

    <div class="auth-logo">
      <div class="brand-name">Pastimes</div>
      <p>Pre-owned branded fashion</p>
    </div>

    <div class="auth-body">
      <h2 style="font-size:1.3rem;font-weight:700;color:var(--white);margin-bottom:4px;">Welcome back</h2>
      <p style="color:var(--muted);font-size:.875rem;margin-bottom:24px;">Sign in to your account to continue</p>

      <?php if($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php endif; ?>

      <form method="POST" action="login.php">

        <div class="form-group">
          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" class="form-control"
                 placeholder="you@example.com"
                 value="<?= htmlspecialchars($email) ?>"
                 required autocomplete="email">
        </div>

        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" class="form-control"
                 placeholder="Your password"
                 required minlength="4">
        </div>

        <button type="submit" class="btn btn-primary" style="width:100%;margin-top:8px;padding:13px;">
          Sign In →
        </button>
      </form>

      <div class="divider-text">or</div>

      <a href="register.php" class="btn btn-ghost" style="width:100%;text-align:center;justify-content:center;">
        Create New Account
      </a>

      <p style="text-align:center;margin-top:20px;font-size:.8rem;color:var(--muted);">
        <a href="admin/adminLogin.php" style="color:var(--muted);">Admin portal →</a>
      </p>

      <!-- Demo credentials hint -->
      <div style="margin-top:20px;padding:14px;background:rgba(108,99,255,0.08);border:1px solid rgba(108,99,255,0.2);border-radius:var(--radius-sm);">
        <div style="font-size:.75rem;font-weight:700;color:var(--primary);text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px;">Demo Credentials</div>
        <div style="font-size:.8rem;color:var(--muted);">Email: <code style="color:var(--text)">j.doe@abc.co.za</code></div>
        <div style="font-size:.8rem;color:var(--muted);">Password: <code style="color:var(--text)">password</code></div>
      </div>

    </div>
  </div>
</div>

<footer>
  <p>© <?= date('Y') ?> <span class="brand">Pastimes</span> – ST10440743 – WEDE6020</p>
</footer>
</body>
</html>
