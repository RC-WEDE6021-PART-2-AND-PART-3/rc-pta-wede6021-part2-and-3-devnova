<?php
/**
 * loadClothingStore.php  –  POE Final Version
 * Connects WITHOUT specifying a database first,
 * creates ClothingStore if needed, then builds all tables.
 * Student : Nkuna Kuhlula  |  ST10440743
 */

// Connect WITHOUT a database name (fixes chicken-and-egg bug)
$conn = new mysqli('localhost', 'root', '');

if ($conn->connect_error) {
    die('<p style="color:red;font-family:Calibri;padding:20px">MySQL connection failed: '
        . $conn->connect_error . ' — Make sure XAMPP MySQL is running.</p>');
}

$log = [];

// Create and select the database
$conn->query("CREATE DATABASE IF NOT EXISTS `ClothingStore` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->query("USE `ClothingStore`");
$conn->set_charset('utf8mb4');
$log[] = ['s', '✔ Database ClothingStore created / selected.'];

// Helper to run a query and log result
function run(mysqli $c, string $sql, string $label, array &$log): void {
    if ($c->query($sql)) $log[] = ['s', "✔ $label"];
    else                  $log[] = ['e', "✘ $label: " . $c->error];
}

// Drop all tables (correct FK order)
$conn->query("SET FOREIGN_KEY_CHECKS = 0");
foreach (['tblMessage','tblOrderLine','tblAorder','tblOrder','tblSellerRequest','tblClothes','tblAdmin','tblUser'] as $t) {
    $conn->query("DROP TABLE IF EXISTS `$t`");
    $log[] = ['i', "🗑 Dropped $t (if existed)"];
}
$conn->query("SET FOREIGN_KEY_CHECKS = 1");

// tblUser
run($conn, "CREATE TABLE tblUser (
    user_id       INT NOT NULL AUTO_INCREMENT,
    first_name    VARCHAR(50)  NOT NULL,
    last_name     VARCHAR(50)  NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone         VARCHAR(20)  DEFAULT NULL,
    role          VARCHAR(20)  NOT NULL DEFAULT 'pending',
    is_verified   TINYINT(1)   NOT NULL DEFAULT 0,
    created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create tblUser", $log);

// tblAdmin
run($conn, "CREATE TABLE tblAdmin (
    admin_id      INT NOT NULL AUTO_INCREMENT,
    first_name    VARCHAR(50)  NOT NULL,
    last_name     VARCHAR(50)  NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (admin_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create tblAdmin", $log);

// tblClothes
run($conn, "CREATE TABLE tblClothes (
    item_id        INT NOT NULL AUTO_INCREMENT,
    title          VARCHAR(100)  NOT NULL,
    brand          VARCHAR(50)   NOT NULL,
    size           VARCHAR(10)   NOT NULL,
    item_condition VARCHAR(20)   NOT NULL DEFAULT 'Good',
    sell_price     DECIMAL(10,2) NOT NULL,
    image_filename VARCHAR(150)  NOT NULL DEFAULT 'item1.jpg',
    description    TEXT          DEFAULT NULL,
    quantity       INT           NOT NULL DEFAULT 10,
    status         VARCHAR(20)   NOT NULL DEFAULT 'available',
    created_at     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create tblClothes", $log);

// tblOrder
run($conn, "CREATE TABLE tblOrder (
    order_id     INT NOT NULL AUTO_INCREMENT,
    user_id      INT NOT NULL,
    session_ref  VARCHAR(100)  NOT NULL,
    order_ref    VARCHAR(20)   NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    status       VARCHAR(20)   NOT NULL DEFAULT 'placed',
    created_at   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (order_id),
    CONSTRAINT fk_ord_user FOREIGN KEY (user_id) REFERENCES tblUser(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create tblOrder", $log);

// tblOrderLine
run($conn, "CREATE TABLE tblOrderLine (
    line_id    INT NOT NULL AUTO_INCREMENT,
    order_id   INT NOT NULL,
    item_id    INT NOT NULL,
    quantity   INT           NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (line_id),
    CONSTRAINT fk_ol_order FOREIGN KEY (order_id) REFERENCES tblOrder(order_id)   ON DELETE CASCADE,
    CONSTRAINT fk_ol_item  FOREIGN KEY (item_id)  REFERENCES tblClothes(item_id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create tblOrderLine", $log);

// tblSellerRequest
run($conn, "CREATE TABLE tblSellerRequest (
    request_id     INT NOT NULL AUTO_INCREMENT,
    user_id        INT NOT NULL,
    title          VARCHAR(100)  NOT NULL,
    brand          VARCHAR(50)   NOT NULL,
    description    TEXT          NOT NULL,
    sell_price     DECIMAL(10,2) NOT NULL,
    size           VARCHAR(10)   NOT NULL,
    item_condition VARCHAR(20)   NOT NULL DEFAULT 'Good',
    image_filename VARCHAR(150)  DEFAULT NULL,
    status         VARCHAR(20)   NOT NULL DEFAULT 'pending',
    created_at     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (request_id),
    CONSTRAINT fk_sr_user FOREIGN KEY (user_id) REFERENCES tblUser(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create tblSellerRequest", $log);

// tblMessage (sender_id nullable so admin can send without tblUser FK)
run($conn, "CREATE TABLE tblMessage (
    message_id  INT NOT NULL AUTO_INCREMENT,
    sender_id   INT          DEFAULT NULL,
    sender_name VARCHAR(100) DEFAULT 'Admin',
    receiver_id INT          NOT NULL,
    subject     VARCHAR(150) NOT NULL,
    body        TEXT         NOT NULL,
    is_read     TINYINT(1)   NOT NULL DEFAULT 0,
    sent_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (message_id),
    CONSTRAINT fk_msg_recv FOREIGN KEY (receiver_id) REFERENCES tblUser(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "Create tblMessage", $log);

// ── Seed tblUser (10 users) ──────────────────────
$conn->query("INSERT INTO tblUser (first_name,last_name,email,password_hash,phone,role,is_verified) VALUES
('John',   'Doe',      'j.doe@abc.co.za',           '5f4dcc3b5aa765d61d8327deb882cf99','0821234567','customer',1),
('Jane',   'Smith',    'j.smith@pastimes.co.za',     'e10adc3949ba59abbe56e057f20f883e','0831234567','customer',1),
('Mike',   'Johnson',  'm.johnson@gmail.com',         '0d107d09f5bbe40cade3de5c71e9e9b7','0841234567','customer',1),
('Sarah',  'Williams', 's.williams@yahoo.co.za',     '40be4e59b9a2a2b5dffb918c0e86b3d7','0851234567','seller',1),
('David',  'Brown',    'd.brown@outlook.com',         'd8578edf8458ce06fbc5bb76a58c5ca4','0861234567','customer',1),
('Lerato', 'Mokoena',  'l.mokoena@gmail.com',         '1a1dc91c907325c69271ddf0c944bc72','0711234567','customer',1),
('Thabo',  'Dlamini',  't.dlamini@webmail.co.za',    'b14a7b8059d9c055954c92674ce60032','0721234567','seller',1),
('Nomsa',  'Zulu',     'n.zulu@pastimes.co.za',       '6512bd43d9caa6e02c990b0a82652dca','0731234567','pending',0),
('Sipho',  'Ndlovu',   's.ndlovu@gmail.com',          'c20ad4d76fe97759aa27a0c99bff6710','0741234567','pending',0),
('Ayanda', 'Khumalo',  'a.khumalo@icloud.com',       'c51ce410c124a10e0db5e4b97fc2af39','0751234567','customer',1)");
$log[] = ['s', '✔ tblUser seeded – 10 users.'];

// ── Seed tblAdmin ────────────────────────────────
// Password: admin123 → md5 = 0192023a7bbd73250516f069df18b500
$conn->query("INSERT INTO tblAdmin (first_name,last_name,email,password_hash) VALUES
('Admin','Pastimes','admin@pastimes.co.za','0192023a7bbd73250516f069df18b500'),
('Super','Admin',   'super@pastimes.co.za','0192023a7bbd73250516f069df18b500')");
$log[] = ['s', '✔ tblAdmin seeded – admin@pastimes.co.za / admin123'];

// ── Seed tblClothes (12 items) ───────────────────
$conn->query("INSERT INTO tblClothes (title,brand,size,item_condition,sell_price,image_filename,description,quantity) VALUES
(\"Levi's 501 Original Jeans\", 'Levis',   '32', 'Good',      499.00,  'item1.jpg', 'Classic straight-leg denim, lightly worn.', 15),
('Nike Air Max Hoodie',          'Nike',    'L',  'Excellent', 650.00,  'item2.jpg', 'Navy blue pullover hoodie, worn twice.', 8),
('Adidas Windbreaker Jacket',    'Adidas',  'M',  'Good',      420.00,  'item3.jpg', 'Black zip-up windbreaker, great condition.', 12),
('Gucci Leather Belt',           'Gucci',   'M',  'Excellent', 1200.00, 'item4.jpg', 'Authentic GG belt, black leather.', 5),
('Puma RS-X Sneakers',           'Puma',    '9',  'Fair',      350.00,  'item5.jpg', 'White sneakers, minor sole wear.', 10),
('Tommy Hilfiger Polo',          'Tommy',   'L',  'Excellent', 380.00,  'item1.jpg', 'Navy polo shirt, no marks.', 20),
('H&M Trench Coat',              'H&M',     'S',  'Good',      550.00,  'item2.jpg', 'Beige classic trench coat.', 6),
('Zara High-Waist Trousers',     'Zara',    'XS', 'Excellent', 290.00,  'item3.jpg', 'Black tailored trousers, like new.', 14),
('New Balance 990 Sneakers',     'NB',      '8',  'Good',      720.00,  'item4.jpg', 'Grey running shoes, minimal wear.', 7),
('Ralph Lauren Oxford Shirt',    'RL',      'M',  'Good',      450.00,  'item5.jpg', 'Light blue button-down shirt.', 18),
('Woolworths Denim Skirt',       'WW',      'S',  'Excellent', 220.00,  'item1.jpg', 'Mid-length denim skirt, no fading.', 9),
('Supreme Box Logo Hoodie',      'Supreme', 'L',  'Good',      1800.00, 'item2.jpg', 'Red box logo hoodie, authentic.', 3)");
$log[] = ['s', '✔ tblClothes seeded – 12 items.'];

// ── Seed tblSellerRequest ─────────────────────────
$conn->query("INSERT INTO tblSellerRequest (user_id,title,brand,description,sell_price,size,item_condition,status) VALUES
(4,'Air Jordan 1 Retro High','Jordan','Clean pair, worn 3 times, comes with original box.',2500.00,'10','Good','pending'),
(7,'Balenciaga Speed Trainer','Balenciaga','Authentic, size EU42, minor creasing.',3200.00,'8','Fair','approved')");
$log[] = ['s', '✔ tblSellerRequest seeded – 2 requests.'];

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Setup – Pastimes</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container" style="max-width:700px;margin:48px auto">
  <div class="card">
    <div class="card-header">
      <h2>⚙ loadClothingStore.php</h2>
      <p>Database setup – Pastimes POE Final</p>
    </div>
    <div class="card-body">
      <?php foreach ($log as [$type, $msg]): ?>
        <div class="alert alert-<?= $type === 's' ? 'success' : ($type === 'e' ? 'danger' : 'info') ?>">
          <?= $msg ?>
        </div>
      <?php endforeach; ?>
      <hr>
      <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:16px">
        <a href="login.php"       class="btn btn-primary">→ Go to Login</a>
        <a href="createTable.php" class="btn btn-ghost">Run createTable.php</a>
      </div>
    </div>
  </div>
</div>
</body>
</html>
