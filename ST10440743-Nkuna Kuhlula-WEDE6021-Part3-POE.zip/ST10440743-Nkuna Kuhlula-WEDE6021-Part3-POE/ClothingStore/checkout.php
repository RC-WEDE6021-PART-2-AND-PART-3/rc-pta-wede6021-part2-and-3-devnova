<?php
/**
 * checkout.php  –  Checkout Page
 * - Shows order reference (orderNum) and session ID
 * - Writes entries to tblOrderLine
 * - Decrements quantity in tblClothes
 * - Empties cart after checkout
 * - Returns user to login/register if not authenticated
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();

// Redirect to login if not authenticated (rubric: checkout returns to login/register)
if(!isset($_SESSION['user_id'])){
    header('Location: login.php?msg=checkout');
    exit;
}

require_once 'DBConn.php';
require_once 'classes/Cart.php';

$cart    = new Cart();
$receipt = null;
$error   = '';

// Only process on POST confirm
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['confirm_checkout'])){
    if($cart->GetCount() === 0){
        $error = 'Your cart is empty. Add items before checking out.';
    } else {
        // Checkout() writes order + orderLines, decrements stock, empties cart
        $receipt = $cart->Checkout($conn, (int)$_SESSION['user_id']);
    }
}

$items     = $cart->GetItems();
$total     = $cart->GetTotal();
$cartCount = $cart->GetCount();
$fullName  = htmlspecialchars($_SESSION['first_name'].' '.$_SESSION['last_name']);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Checkout – Pastimes</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="user-bar">
  <span>👤 User <strong><?=$fullName?></strong> is logged in</span>
  <a href="logout.php">Logout</a>
</div>

<nav class="navbar">
  <a class="navbar-brand" href="index.php">Pastimes</a>
  <ul class="navbar-links">
    <li><a href="shop.php">Shop</a></li>
    <li><a href="cart.php">🛒 Cart</a></li>
    <li><a href="logout.php" class="btn btn-accent btn-sm">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:48px;padding-bottom:80px;max-width:760px">

  <?php if($receipt): ?>
  <!-- ── Success Receipt ─────────────────────────── -->
  <div class="receipt-box">
    <div class="receipt-icon">✅</div>
    <h2>Order Confirmed!</h2>
    <p style="color:var(--muted);margin-bottom:8px">Thank you <strong style="color:var(--white)"><?=$fullName?></strong> — your order has been placed successfully.</p>

    <!-- Order reference and session ID (rubric requirement) -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:28px 0;text-align:left">
      <div class="receipt-ref" style="display:block">
        <div style="font-size:.75rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px">Order Number (orderNum)</div>
        <code><?=htmlspecialchars($receipt['order_ref'])?></code>
      </div>
      <div class="receipt-ref" style="display:block">
        <div style="font-size:.75rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px">Session ID (sessionId)</div>
        <code style="font-size:.85rem"><?=htmlspecialchars(substr($receipt['session_ref'],0,20))?>...</code>
      </div>
    </div>

    <div style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius-sm);padding:16px 20px;margin-bottom:24px;text-align:left">
      <div style="font-size:.78rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Order Summary</div>
      <div style="font-size:1rem;color:var(--muted)">Items written to <code style="color:var(--primary)">tblOrderLine</code> · Stock decremented in <code style="color:var(--primary)">tblClothes</code></div>
      <div style="margin-top:12px;font-size:1.4rem;font-weight:800;color:var(--accent)">Total Paid: R <?=number_format($receipt['total'],2)?></div>
    </div>

    <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
      <a href="shop.php" class="btn btn-ghost">← Continue Shopping</a>
      <a href="history.php" class="btn btn-primary">View Order History</a>
    </div>
  </div>

  <?php elseif($cartCount === 0 && !$receipt): ?>
  <!-- ── Empty Cart ──────────────────────────────── -->
  <div class="card" style="text-align:center;padding:48px">
    <div style="font-size:3rem;margin-bottom:16px">🛒</div>
    <h2 style="color:var(--white);margin-bottom:8px">Your cart is empty</h2>
    <p style="color:var(--muted);margin-bottom:24px">Add some items before checking out.</p>
    <a href="shop.php" class="btn btn-primary">Browse the Shop</a>
  </div>

  <?php else: ?>
  <!-- ── Order Review ─────────────────────────────── -->
  <?php if($error): ?><div class="alert alert-danger"><?=$error?></div><?php endif; ?>

  <div class="card">
    <div class="card-header">
      <h2>Review Your Order</h2>
      <p>Confirm below to place your order and generate your receipt</p>
    </div>
    <div class="card-body" style="padding:0">
      <div class="table-wrapper">
        <table>
          <thead><tr><th>Image</th><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
          <tbody>
            <?php foreach($items as $item): ?>
            <tr>
              <td><img src="images/<?=htmlspecialchars($item['image_filename'])?>" style="width:56px;height:56px;object-fit:cover;border-radius:8px" onerror="this.src='images/item1.jpg'"></td>
              <td><strong><?=htmlspecialchars($item['title'])?></strong></td>
              <td>R <?=number_format($item['sell_price'],2)?></td>
              <td><?=$item['quantity']?></td>
              <td><strong style="color:var(--accent)">R <?=number_format($item['sell_price']*$item['quantity'],2)?></strong></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="4" style="text-align:right;font-weight:700">Order Total:</td>
              <td style="font-size:1.3rem;font-weight:800;color:var(--accent)">R <?=number_format($total,2)?></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
    <div style="padding:24px;display:flex;gap:12px;justify-content:flex-end;flex-wrap:wrap;border-top:1px solid var(--border)">
      <a href="cart.php" class="btn btn-ghost">← Edit Cart</a>
      <form method="POST">
        <button type="submit" name="confirm_checkout" class="btn btn-primary btn-lg">✅ Confirm &amp; Place Order</button>
      </form>
    </div>
  </div>
  <?php endif; ?>
</div>

<footer>
  <p>© <?=date('Y')?> <span class="brand">Pastimes</span> &nbsp;|&nbsp; ST10440743</p>
</footer>
</body>
</html>
