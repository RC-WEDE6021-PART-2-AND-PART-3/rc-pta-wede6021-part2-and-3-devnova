<?php
/**
 * admin/dashboard.php  –  Admin Dashboard (POE Final)
 * - Verify pending users
 * - Add, Edit, Delete customers
 * - Links to manageClothes and adminMessages
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
if(!isset($_SESSION['admin_id'])){ header('Location: adminLogin.php'); exit; }
require_once '../DBConn.php';

$msg=''; $msgType='success';
$action = $_GET['action'] ?? '';
$userId = isset($_GET['uid']) ? (int)$_GET['uid'] : 0;

// VERIFY
if($action==='verify' && $userId>0){
    $s=$conn->prepare("UPDATE tblUser SET is_verified=1, role='customer' WHERE user_id=?");
    $s->bind_param('i',$userId); $s->execute(); $s->close();
    $msg='✔ User verified successfully. They can now log in.';
}

// DELETE
if($action==='delete' && $userId>0){
    $s=$conn->prepare("DELETE FROM tblUser WHERE user_id=?");
    $s->bind_param('i',$userId); $s->execute(); $s->close();
    $msg='User deleted.';
}

// ADD
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['add_user'])){
    $fn=$_POST['first_name']??''; $ln=$_POST['last_name']??'';
    $em=$_POST['email']??'';      $ph=$_POST['phone']??'';
    $pw=$_POST['password']??'';   $role=$_POST['role']??'customer';
    if($fn&&$ln&&$em&&$pw){
        $hash=md5($pw);
        $s=$conn->prepare("INSERT INTO tblUser(first_name,last_name,email,password_hash,phone,role,is_verified)VALUES(?,?,?,?,?,?,1)");
        $s->bind_param('ssssss',$fn,$ln,$em,$hash,$ph,$role);
        if($s->execute()) $msg="Customer <strong>$fn $ln</strong> added.";
        else{$msg='Add failed (email may exist).';$msgType='danger';}
        $s->close();
    } else {$msg='Fill in all required fields.';$msgType='danger';}
}

// UPDATE
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_user'])){
    $uid=(int)$_POST['edit_uid'];
    $fn=$_POST['edit_fn']??''; $ln=$_POST['edit_ln']??'';
    $em=$_POST['edit_em']??''; $ph=$_POST['edit_ph']??'';
    $role=$_POST['edit_role']??'customer';
    $s=$conn->prepare("UPDATE tblUser SET first_name=?,last_name=?,email=?,phone=?,role=? WHERE user_id=?");
    $s->bind_param('sssssi',$fn,$ln,$em,$ph,$role,$uid);
    if($s->execute()) $msg='Customer updated.';
    else{$msg='Update failed.';$msgType='danger';}
    $s->close();
}

// Fetch edit user
$editUser=null;
if($action==='edit' && $userId>0){
    $s=$conn->prepare("SELECT * FROM tblUser WHERE user_id=?");
    $s->bind_param('i',$userId); $s->execute();
    $editUser=$s->get_result()->fetch_assoc(); $s->close();
}

$users=$conn->query("SELECT * FROM tblUser ORDER BY is_verified ASC, created_at DESC")->fetch_all(MYSQLI_ASSOC);
$total=count($users);
$pending=count(array_filter($users,fn($u)=>$u['is_verified']==0));
$verified=$total-$pending;
$clothesCount=$conn->query("SELECT COUNT(*) c FROM tblClothes")->fetch_assoc()['c'];
$ordersCount=$conn->query("SELECT COUNT(*) c FROM tblOrder")->fetch_assoc()['c'];
$reqCount=$conn->query("SELECT COUNT(*) c FROM tblSellerRequest WHERE status='pending'")->fetch_assoc()['c'];
$conn->close();
$adminName=htmlspecialchars($_SESSION['admin_first_name'].' '.$_SESSION['admin_last_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Admin Dashboard – Pastimes</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="user-bar">
  <span>⚙ Admin: <strong><?=$adminName?></strong><span class="role-tag role-admin" style="margin-left:8px">ADMIN</span></span>
  <div><a href="../index.php">View Site</a> &nbsp;|&nbsp; <a href="adminLogout.php">Logout</a></div>
</div>

<nav class="navbar">
  <a class="navbar-brand" href="dashboard.php">Pastimes Admin</a>
  <ul class="navbar-links">
    <li><a href="dashboard.php" class="active">👥 Users</a></li>
    <li><a href="manageClothes.php">👗 Clothes</a></li>
    <li><a href="adminMessages.php">💬 Messages</a></li>
    <li><a href="adminLogout.php" class="btn btn-accent btn-sm">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:32px;padding-bottom:80px">

  <?php if($msg):?><div class="alert alert-<?=$msgType?>"><?=$msg?></div><?php endif;?>

  <!-- Stats -->
  <div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));margin-bottom:32px">
    <div class="stat-card"><div class="num"><?=$total?></div><div class="lbl">Total Users</div></div>
    <div class="stat-card"><div class="num" style="background:linear-gradient(135deg,#22c55e,#16a34a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text"><?=$verified?></div><div class="lbl">Verified</div></div>
    <div class="stat-card"><div class="num" style="background:linear-gradient(135deg,#ef4444,#dc2626);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text"><?=$pending?></div><div class="lbl">Pending</div></div>
    <div class="stat-card"><div class="num"><?=$clothesCount?></div><div class="lbl">Items Listed</div></div>
    <div class="stat-card"><div class="num"><?=$ordersCount?></div><div class="lbl">Orders</div></div>
    <div class="stat-card"><div class="num" style="background:linear-gradient(135deg,#f59e0b,#d97706);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text"><?=$reqCount?></div><div class="lbl">Seller Requests</div></div>
  </div>

  <!-- Quick Links -->
  <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:28px">
    <a href="manageClothes.php" class="btn btn-ghost">👗 Manage Clothing Items</a>
    <a href="adminMessages.php" class="btn btn-ghost">💬 Message Users</a>
    <a href="manageClothes.php" class="btn btn-ghost">📬 Review Seller Requests (<?=$reqCount?>)</a>
  </div>

  <!-- Add Customer -->
  <div class="card" style="margin-bottom:24px">
    <div class="card-header"><h2>➕ Add New Customer</h2></div>
    <div class="card-body">
      <form method="POST" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;align-items:end">
        <div class="form-group" style="margin:0"><label>First Name *</label><input type="text" name="first_name" class="form-control" required placeholder="First"></div>
        <div class="form-group" style="margin:0"><label>Last Name *</label><input type="text" name="last_name" class="form-control" required placeholder="Last"></div>
        <div class="form-group" style="margin:0"><label>Email *</label><input type="email" name="email" class="form-control" required placeholder="email@..."></div>
        <div class="form-group" style="margin:0"><label>Phone</label><input type="tel" name="phone" class="form-control" placeholder="082..."></div>
        <div class="form-group" style="margin:0"><label>Role</label>
          <select name="role" class="form-control"><option value="customer">Customer</option><option value="seller">Seller</option></select>
        </div>
        <div class="form-group" style="margin:0"><label>Password *</label><input type="password" name="password" class="form-control" required minlength="4" placeholder="Password"></div>
        <div><button type="submit" name="add_user" class="btn btn-success" style="width:100%">Add User</button></div>
      </form>
    </div>
  </div>

  <!-- Edit Customer -->
  <?php if($editUser):?>
  <div class="card" style="margin-bottom:24px">
    <div class="card-header"><h2>✏ Edit: <?=htmlspecialchars($editUser['first_name'].' '.$editUser['last_name'])?></h2></div>
    <div class="card-body">
      <form method="POST" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;align-items:end">
        <input type="hidden" name="edit_uid" value="<?=$editUser['user_id']?>">
        <div class="form-group" style="margin:0"><label>First Name</label><input type="text" name="edit_fn" class="form-control" value="<?=htmlspecialchars($editUser['first_name'])?>" required></div>
        <div class="form-group" style="margin:0"><label>Last Name</label><input type="text" name="edit_ln" class="form-control" value="<?=htmlspecialchars($editUser['last_name'])?>" required></div>
        <div class="form-group" style="margin:0"><label>Email</label><input type="email" name="edit_em" class="form-control" value="<?=htmlspecialchars($editUser['email'])?>" required></div>
        <div class="form-group" style="margin:0"><label>Phone</label><input type="tel" name="edit_ph" class="form-control" value="<?=htmlspecialchars($editUser['phone'])?>"></div>
        <div class="form-group" style="margin:0"><label>Role</label>
          <select name="edit_role" class="form-control">
            <?php foreach(['customer','seller','pending'] as $r):?>
            <option value="<?=$r?>" <?=$r===$editUser['role']?'selected':''?>><?=ucfirst($r)?></option>
            <?php endforeach;?>
          </select>
        </div>
        <div><button type="submit" name="update_user" class="btn btn-primary" style="width:100%">Save Changes</button></div>
      </form>
    </div>
  </div>
  <?php endif;?>

  <!-- Users Table -->
  <div class="card">
    <div class="card-header"><h2>👥 All Registered Users</h2><p>Manage, verify, edit and delete accounts</p></div>
    <div class="card-body" style="padding:0">
      <div class="table-wrapper">
        <table>
          <thead>
            <tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php foreach($users as $u):?>
            <tr style="<?=$u['is_verified']==0?'background:rgba(239,68,68,0.04)':''?>">
              <td style="color:var(--muted);font-size:.8rem"><?=$u['user_id']?></td>
              <td><strong style="color:var(--white)"><?=htmlspecialchars($u['first_name'].' '.$u['last_name'])?></strong></td>
              <td style="font-size:.85rem"><?=htmlspecialchars($u['email'])?></td>
              <td style="font-size:.85rem;color:var(--muted)"><?=htmlspecialchars($u['phone']??'—')?></td>
              <td><span class="role-tag role-<?=$u['role']??'pending'?>"><?=htmlspecialchars($u['role'])?></span></td>
              <td>
                <?php if($u['is_verified']):?>
                  <span class="role-tag role-customer">✔ Verified</span>
                <?php else:?>
                  <span class="role-tag role-pending">⏳ Pending</span>
                <?php endif;?>
              </td>
              <td style="font-size:.78rem;color:var(--muted)"><?=date('d M Y',strtotime($u['created_at']))?></td>
              <td>
                <div style="display:flex;gap:6px;flex-wrap:wrap">
                  <?php if(!$u['is_verified']):?>
                    <a href="dashboard.php?action=verify&uid=<?=$u['user_id']?>" class="btn btn-success btn-sm">✔ Verify</a>
                  <?php endif;?>
                  <a href="dashboard.php?action=edit&uid=<?=$u['user_id']?>" class="btn btn-secondary btn-sm">✏ Edit</a>
                  <a href="dashboard.php?action=delete&uid=<?=$u['user_id']?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this user permanently?')">🗑</a>
                </div>
              </td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<footer><p>© <?=date('Y')?> <span class="brand">Pastimes</span> Admin &nbsp;|&nbsp; ST10440743</p></footer>
</body>
</html>
