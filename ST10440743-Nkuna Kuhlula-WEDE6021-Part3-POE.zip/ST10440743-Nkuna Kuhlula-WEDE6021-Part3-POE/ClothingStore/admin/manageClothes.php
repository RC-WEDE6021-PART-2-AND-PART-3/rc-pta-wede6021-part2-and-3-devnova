<?php
/**
 * admin/manageClothes.php
 * Full CRUD for tblClothes and tblSellerRequest approval.
 * Admin can Add, Edit, Delete clothing items.
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
if(!isset($_SESSION['admin_id'])){ header('Location: adminLogin.php'); exit; }
require_once '../DBConn.php';

$msg=''; $msgType='success';
$action = $_GET['action'] ?? '';
$itemId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// DELETE
if($action==='delete' && $itemId>0){
    $s=$conn->prepare("DELETE FROM tblClothes WHERE item_id=?"); $s->bind_param('i',$itemId); $s->execute(); $s->close();
    $msg='Item deleted.';
}

// ADD
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['add_item'])){
    $title=$_POST['title']??''; $brand=$_POST['brand']??''; $size=$_POST['size']??'';
    $cond=$_POST['item_condition']??'Good'; $price=(float)($_POST['sell_price']??0);
    $desc=$_POST['description']??''; $qty=(int)($_POST['quantity']??1);
    $imgFile='item1.jpg';
    if(isset($_FILES['image'])&&$_FILES['image']['error']===0){
        $ext=strtolower(pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION));
        if(in_array($ext,['jpg','jpeg','png','webp'])){
            $imgFile='prod_'.time().'.'.$ext;
            move_uploaded_file($_FILES['image']['tmp_name'],__DIR__.'/../images/'.$imgFile);
        }
    }
    $s=$conn->prepare("INSERT INTO tblClothes(title,brand,size,item_condition,sell_price,image_filename,description,quantity) VALUES(?,?,?,?,?,?,?,?)");
    $s->bind_param('ssssdssi',$title,$brand,$size,$cond,$price,$imgFile,$desc,$qty);
    if($s->execute()) $msg="Item <strong>$title</strong> added."; else{$msg='Add failed: '.$conn->error;$msgType='danger';}
    $s->close();
}

// UPDATE
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_item'])){
    $uid=(int)$_POST['edit_id'];
    $title=$_POST['edit_title']??''; $brand=$_POST['edit_brand']??'';
    $size=$_POST['edit_size']??''; $cond=$_POST['edit_condition']??'Good';
    $price=(float)($_POST['edit_price']??0); $desc=$_POST['edit_desc']??''; $qty=(int)($_POST['edit_qty']??1);
    $imgFile=$_POST['existing_img']??'item1.jpg';
    if(isset($_FILES['edit_image'])&&$_FILES['edit_image']['error']===0){
        $ext=strtolower(pathinfo($_FILES['edit_image']['name'],PATHINFO_EXTENSION));
        if(in_array($ext,['jpg','jpeg','png','webp'])){
            $imgFile='prod_'.time().'.'.$ext;
            move_uploaded_file($_FILES['edit_image']['tmp_name'],__DIR__.'/../images/'.$imgFile);
        }
    }
    $s=$conn->prepare("UPDATE tblClothes SET title=?,brand=?,size=?,item_condition=?,sell_price=?,image_filename=?,description=?,quantity=? WHERE item_id=?");
    $s->bind_param('ssssdssii',$title,$brand,$size,$cond,$price,$imgFile,$desc,$qty,$uid);
    if($s->execute()) $msg='Item updated.'; else{$msg='Update failed.';$msgType='danger';}
    $s->close();
}

// APPROVE seller request → insert to tblClothes
if($action==='approve' && $itemId>0){
    $s=$conn->prepare("SELECT * FROM tblSellerRequest WHERE request_id=?");
    $s->bind_param('i',$itemId); $s->execute();
    $req=$s->get_result()->fetch_assoc(); $s->close();
    if($req){
        $ins=$conn->prepare("INSERT INTO tblClothes(title,brand,size,item_condition,sell_price,image_filename,description,quantity) VALUES(?,?,?,?,?,?,?,5)");
        $img=$req['image_filename']?:('item'.rand(1,5).'.jpg');
        $ins->bind_param('ssssdss',$req['title'],$req['brand'],$req['size'],$req['item_condition'],$req['sell_price'],$img,$req['description']);
        $ins->execute(); $ins->close();
        $upd=$conn->prepare("UPDATE tblSellerRequest SET status='approved' WHERE request_id=?");
        $upd->bind_param('i',$itemId); $upd->execute(); $upd->close();
        $msg='Seller request approved and item listed.';
    }
}

// Fetch edit item
$editItem=null;
if($action==='edit' && $itemId>0){
    $s=$conn->prepare("SELECT * FROM tblClothes WHERE item_id=?"); $s->bind_param('i',$itemId); $s->execute();
    $editItem=$s->get_result()->fetch_assoc(); $s->close();
}

// Fetch all clothes
$clothes=$conn->query("SELECT * FROM tblClothes ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
// Fetch seller requests
$sellerReqs=$conn->query("SELECT sr.*,u.first_name,u.last_name FROM tblSellerRequest sr JOIN tblUser u ON u.user_id=sr.user_id ORDER BY sr.created_at DESC")->fetch_all(MYSQLI_ASSOC);
$conn->close();
$adminName=htmlspecialchars($_SESSION['admin_first_name'].' '.$_SESSION['admin_last_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Manage Clothes – Admin</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="user-bar">
  <span>⚙ Admin: <strong><?=$adminName?></strong><span class="role-tag role-admin" style="margin-left:8px">ADMIN</span></span>
  <div><a href="dashboard.php">Dashboard</a> &nbsp;|&nbsp; <a href="adminLogout.php">Logout</a></div>
</div>
<nav class="navbar">
  <a class="navbar-brand" href="../index.php">Pastimes Admin</a>
  <ul class="navbar-links">
    <li><a href="dashboard.php">Users</a></li>
    <li><a href="manageClothes.php" class="active">Clothes</a></li>
    <li><a href="adminMessages.php">Messages</a></li>
    <li><a href="adminLogout.php" class="btn btn-accent btn-sm">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:32px;padding-bottom:80px">
  <?php if($msg):?><div class="alert alert-<?=$msgType?>"><?=$msg?></div><?php endif;?>

  <!-- Add Item Form -->
  <div class="card" style="margin-bottom:28px">
    <div class="card-header"><h2>➕ Add New Clothing Item</h2></div>
    <div class="card-body">
      <form method="POST" enctype="multipart/form-data" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;align-items:end">
        <div class="form-group" style="margin:0"><label>Title *</label><input type="text" name="title" class="form-control" required placeholder="Item title"></div>
        <div class="form-group" style="margin:0"><label>Brand *</label><input type="text" name="brand" class="form-control" required placeholder="Brand"></div>
        <div class="form-group" style="margin:0"><label>Size *</label><input type="text" name="size" class="form-control" required placeholder="M, L, 9..."></div>
        <div class="form-group" style="margin:0"><label>Condition</label><select name="item_condition" class="form-control"><option value="Excellent">Excellent</option><option value="Good" selected>Good</option><option value="Fair">Fair</option></select></div>
        <div class="form-group" style="margin:0"><label>Price (R) *</label><input type="number" name="sell_price" class="form-control" step="0.01" min="1" required></div>
        <div class="form-group" style="margin:0"><label>Quantity</label><input type="number" name="quantity" class="form-control" min="1" value="10"></div>
        <div class="form-group" style="margin:0"><label>Image</label><input type="file" name="image" class="form-control" accept="image/*"></div>
        <div class="form-group" style="margin:0"><label>Description</label><input type="text" name="description" class="form-control" placeholder="Short description"></div>
        <div style="margin:0"><button type="submit" name="add_item" class="btn btn-success" style="width:100%">Add Item</button></div>
      </form>
    </div>
  </div>

  <!-- Edit Form -->
  <?php if($editItem):?>
  <div class="card" style="margin-bottom:28px">
    <div class="card-header"><h2>✏ Edit: <?=htmlspecialchars($editItem['title'])?></h2></div>
    <div class="card-body">
      <form method="POST" enctype="multipart/form-data" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;align-items:end">
        <input type="hidden" name="edit_id" value="<?=$editItem['item_id']?>">
        <input type="hidden" name="existing_img" value="<?=htmlspecialchars($editItem['image_filename'])?>">
        <div class="form-group" style="margin:0"><label>Title</label><input type="text" name="edit_title" class="form-control" value="<?=htmlspecialchars($editItem['title'])?>" required></div>
        <div class="form-group" style="margin:0"><label>Brand</label><input type="text" name="edit_brand" class="form-control" value="<?=htmlspecialchars($editItem['brand'])?>" required></div>
        <div class="form-group" style="margin:0"><label>Size</label><input type="text" name="edit_size" class="form-control" value="<?=htmlspecialchars($editItem['size'])?>" required></div>
        <div class="form-group" style="margin:0"><label>Condition</label><select name="edit_condition" class="form-control"><?php foreach(['Excellent','Good','Fair'] as $c):?><option <?=$c===$editItem['item_condition']?'selected':''?>><?=$c?></option><?php endforeach;?></select></div>
        <div class="form-group" style="margin:0"><label>Price</label><input type="number" name="edit_price" class="form-control" value="<?=$editItem['sell_price']?>" step="0.01" min="1" required></div>
        <div class="form-group" style="margin:0"><label>Quantity</label><input type="number" name="edit_qty" class="form-control" value="<?=$editItem['quantity']?>" min="0"></div>
        <div class="form-group" style="margin:0"><label>New Image</label><input type="file" name="edit_image" class="form-control" accept="image/*"></div>
        <div class="form-group" style="margin:0"><label>Description</label><input type="text" name="edit_desc" class="form-control" value="<?=htmlspecialchars($editItem['description'])?>"></div>
        <div style="margin:0"><button type="submit" name="update_item" class="btn btn-primary" style="width:100%">Save Changes</button></div>
      </form>
    </div>
  </div>
  <?php endif;?>

  <!-- Clothes Table -->
  <div class="card" style="margin-bottom:28px">
    <div class="card-header"><h2>👗 All Clothing Items (<?=count($clothes)?>)</h2></div>
    <div class="card-body" style="padding:0">
      <div class="table-wrapper">
        <table>
          <thead><tr><th>Image</th><th>Title</th><th>Brand</th><th>Size</th><th>Cond.</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            <?php foreach($clothes as $c):?>
            <tr>
              <td><img src="../images/<?=htmlspecialchars($c['image_filename'])?>" style="width:52px;height:52px;object-fit:cover;border-radius:8px" onerror="this.src='../images/item1.jpg'"></td>
              <td><strong style="color:var(--white)"><?=htmlspecialchars($c['title'])?></strong></td>
              <td><?=htmlspecialchars($c['brand'])?></td>
              <td><?=htmlspecialchars($c['size'])?></td>
              <td><span class="condition-badge badge-<?=strtolower($c['item_condition'])?>"><?=$c['item_condition']?></span></td>
              <td style="color:var(--accent);font-weight:700">R <?=number_format($c['sell_price'],2)?></td>
              <td><?=$c['quantity']?></td>
              <td><span class="role-tag <?=$c['status']==='available'?'role-customer':'role-pending'?>"><?=$c['status']?></span></td>
              <td>
                <div style="display:flex;gap:6px;flex-wrap:wrap">
                  <a href="manageClothes.php?action=edit&id=<?=$c['item_id']?>" class="btn btn-secondary btn-sm">✏ Edit</a>
                  <a href="manageClothes.php?action=delete&id=<?=$c['item_id']?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this item?')">🗑</a>
                </div>
              </td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Seller Requests -->
  <div class="card">
    <div class="card-header"><h2>📬 Seller Requests</h2><p>Review and approve seller submissions</p></div>
    <div class="card-body" style="padding:0">
      <div class="table-wrapper">
        <table>
          <thead><tr><th>Seller</th><th>Item</th><th>Brand</th><th>Price</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>
            <?php foreach($sellerReqs as $r):?>
            <tr>
              <td><?=htmlspecialchars($r['first_name'].' '.$r['last_name'])?></td>
              <td><?=htmlspecialchars($r['title'])?></td>
              <td><?=htmlspecialchars($r['brand'])?></td>
              <td>R <?=number_format($r['sell_price'],2)?></td>
              <td><span class="role-tag <?=$r['status']==='approved'?'role-customer':'role-seller'?>"><?=$r['status']?></span></td>
              <td>
                <?php if($r['status']==='pending'):?>
                  <a href="manageClothes.php?action=approve&id=<?=$r['request_id']?>" class="btn btn-success btn-sm">✔ Approve</a>
                <?php else:?><span style="color:var(--muted);font-size:.8rem">Processed</span><?php endif;?>
              </td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<footer><p>© <?=date('Y')?> <span class="brand">Pastimes</span> Admin &nbsp;|&nbsp; ST10440743</p></footer>
</body>
</html>
