<?php
/**
 * admin/adminMessages.php
 * Admin sends messages to buyers and sellers.
 * Uses sender_name instead of FK sender_id to avoid FK issues.
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: adminLogin.php'); exit; }
require_once '../DBConn.php';

$msg = '';
$adminName = $_SESSION['admin_first_name'] . ' ' . $_SESSION['admin_last_name'];

// Send message as admin (sender_id = NULL, sender_name = admin name)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_admin_msg'])) {
    $to      = (int)   ($_POST['receiver_id'] ?? 0);
    $subject = '[Admin] ' . trim($_POST['subject'] ?? '');
    $body    = trim($_POST['body'] ?? '');

    if ($to && $subject && $body) {
        $stmt = $conn->prepare(
            "INSERT INTO tblMessage (sender_id, sender_name, receiver_id, subject, body)
             VALUES (NULL, ?, ?, ?, ?)"
        );
        $stmt->bind_param('siss', $adminName, $to, $subject, $body);
        if ($stmt->execute()) $msg = 'Message sent successfully to user.';
        else $msg = 'Send failed: ' . $conn->error;
        $stmt->close();
    } else {
        $msg = 'Please fill in all fields.';
    }
}

// Fetch all users to message
$users = $conn->query(
    "SELECT user_id, first_name, last_name, role FROM tblUser
     WHERE is_verified = 1 ORDER BY role, first_name"
)->fetch_all(MYSQLI_ASSOC);

// Fetch all messages (most recent 50)
$allMsgs = $conn->query(
    "SELECT m.*, r.first_name AS rf, r.last_name AS rl
     FROM tblMessage m
     JOIN tblUser r ON r.user_id = m.receiver_id
     ORDER BY m.sent_at DESC LIMIT 50"
)->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Admin Messages – Pastimes</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="user-bar">
  <span>⚙ Admin: <strong><?= htmlspecialchars($adminName) ?></strong>
    <span class="role-tag role-admin" style="margin-left:8px">ADMIN</span>
  </span>
  <a href="adminLogout.php">Logout</a>
</div>

<nav class="navbar">
  <a class="navbar-brand" href="../index.php">Pastimes Admin</a>
  <ul class="navbar-links">
    <li><a href="dashboard.php">👥 Users</a></li>
    <li><a href="manageClothes.php">👗 Clothes</a></li>
    <li><a href="adminMessages.php" class="active">💬 Messages</a></li>
    <li><a href="adminLogout.php" class="btn btn-accent btn-sm">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:32px;padding-bottom:80px">
  <h2 class="section-title" style="margin-bottom:32px">📨 Admin Messages</h2>

  <?php if ($msg): ?>
    <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">

    <!-- Compose -->
    <div class="card">
      <div class="card-header">
        <h2>✉️ Send Message to User</h2>
        <p>Communicate with buyers and sellers about deliveries and orders</p>
      </div>
      <div class="card-body">
        <form method="POST" style="display:grid;gap:16px">
          <div class="form-group" style="margin:0">
            <label>Send To</label>
            <select name="receiver_id" class="form-control" required>
              <option value="">— Select user —</option>
              <?php foreach ($users as $u): ?>
                <option value="<?= $u['user_id'] ?>">
                  <?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name']) ?>
                  (<?= $u['role'] ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label>Subject</label>
            <input type="text" name="subject" class="form-control"
                   placeholder="e.g. Order confirmed, Delivery update..." required>
          </div>
          <div class="form-group" style="margin:0">
            <label>Message</label>
            <textarea name="body" class="form-control" rows="5"
                      placeholder="Write your message here..." required
                      style="resize:vertical"></textarea>
          </div>
          <button type="submit" name="send_admin_msg" class="btn btn-primary">
            Send Message →
          </button>
        </form>
      </div>
    </div>

    <!-- All Messages -->
    <div class="card">
      <div class="card-header">
        <h2>📋 All Platform Messages</h2>
        <p><?= count($allMsgs) ?> messages on platform</p>
      </div>
      <div class="card-body" style="padding:0;max-height:560px;overflow-y:auto">
        <?php if (empty($allMsgs)): ?>
          <div style="padding:32px;text-align:center;color:var(--muted)">No messages yet</div>
        <?php else: ?>
          <?php foreach ($allMsgs as $m): ?>
          <div style="padding:14px 20px;border-bottom:1px solid var(--border)">
            <div style="display:flex;justify-content:space-between;margin-bottom:4px;flex-wrap:wrap;gap:8px">
              <span style="font-size:.82rem">
                <strong style="color:var(--primary)">
                  <?= htmlspecialchars($m['sender_name'] ?? 'Unknown') ?>
                </strong>
                <span style="color:var(--muted)">→</span>
                <strong style="color:var(--accent)">
                  <?= htmlspecialchars($m['rf'] . ' ' . $m['rl']) ?>
                </strong>
              </span>
              <span style="font-size:.75rem;color:var(--muted)">
                <?= date('d M Y H:i', strtotime($m['sent_at'])) ?>
              </span>
            </div>
            <div style="font-size:.85rem;font-weight:600;color:var(--white);margin-bottom:2px">
              <?= htmlspecialchars($m['subject']) ?>
            </div>
            <div style="font-size:.8rem;color:var(--muted)">
              <?= htmlspecialchars(substr($m['body'], 0, 100)) ?>...
            </div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

  </div>
</div>

<footer>
  <p>© <?= date('Y') ?> <span class="brand">Pastimes</span> Admin &nbsp;|&nbsp; ST10440743</p>
</footer>
</body>
</html>
