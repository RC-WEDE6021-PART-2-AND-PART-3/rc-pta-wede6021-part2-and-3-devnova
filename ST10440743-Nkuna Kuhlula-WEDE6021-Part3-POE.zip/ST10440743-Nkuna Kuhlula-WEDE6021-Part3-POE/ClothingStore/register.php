<?php
/**
 * register.php  –  New User Registration
 * - All fields required (HTML5 + server-side)
 * - Password hashed with MD5
 * - New users set to role='pending', is_verified=0
 * - Admin must verify before login is allowed
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
if(isset($_SESSION['user_id'])){ header('Location: index.php'); exit; }

require_once 'DBConn.php';

$error   = '';
$success = '';
$fn = $ln = $email = $phone = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $fn       = trim($_POST['first_name'] ?? '');
    $ln       = trim($_POST['last_name']  ?? '');
    $email    = trim($_POST['email']      ?? '');
    $phone    = trim($_POST['phone']      ?? '');
    $password = trim($_POST['password']   ?? '');
    $confirm  = trim($_POST['confirm']    ?? '');

    if(!$fn || !$ln || !$email || !$password || !$confirm){
        $error = 'All fields are required. Please complete the form.';
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $error = 'Please enter a valid email address.';
    } elseif(strlen($password) < 6){
        $error = 'Password must be at least 6 characters long.';
    } elseif($password !== $confirm){
        $error = 'Passwords do not match. Please try again.';
    } else {
        // Check if email exists
        $chk = $conn->prepare("SELECT user_id FROM tblUser WHERE email=?");
        $chk->bind_param('s',$email); $chk->execute(); $chk->store_result();
        if($chk->num_rows > 0){
            $error = 'An account with that email already exists. Please login.';
        } else {
            $hash = md5($password);
            $ins  = $conn->prepare(
                "INSERT INTO tblUser(first_name,last_name,email,password_hash,phone,role,is_verified)
                 VALUES(?,?,?,?,?,'pending',0)"
            );
            $ins->bind_param('sssss',$fn,$ln,$email,$hash,$phone);
            if($ins->execute()){
                $success = "🎉 Account created! Welcome <strong>$fn $ln</strong>. Your account is <strong>pending admin verification</strong> — you will be able to login once approved.";
                $fn = $ln = $email = $phone = '';
            } else {
                $error = 'Registration failed. Please try again.';
            }
            $ins->close();
        }
        $chk->close();
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Register – Pastimes</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    body { background: radial-gradient(ellipse 80% 60% at 50% -10%, rgba(255,101,132,0.15) 0%, transparent 60%), var(--bg); }
    .auth-box { background:var(--card); border:1px solid var(--border); border-radius:var(--radius); box-shadow:0 24px 64px rgba(0,0,0,0.5); width:100%; max-width:500px; }
    .auth-logo { text-align:center; padding:36px 32px 0; }
    .auth-logo .brand-name { font-size:2rem; font-weight:900; background:linear-gradient(135deg,var(--primary),var(--accent)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
    .auth-logo p { color:var(--muted); font-size:.875rem; margin-top:4px; }
    .auth-body { padding:28px 32px 36px; }
    .two-col { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
    @media(max-width:480px){ .two-col { grid-template-columns:1fr; } }
  </style>
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="index.php">Pastimes</a>
  <ul class="navbar-links">
    <li><a href="login.php">Login</a></li>
    <li><a href="register.php" class="btn btn-primary btn-sm active">Register</a></li>
  </ul>
</nav>

<div class="auth-wrapper">
  <div class="auth-box">

    <div class="auth-logo">
      <div class="brand-name">Pastimes</div>
      <p>Create your free account</p>
    </div>

    <div class="auth-body">
      <h2 style="font-size:1.3rem;font-weight:700;color:var(--white);margin-bottom:4px;">Join Pastimes</h2>
      <p style="color:var(--muted);font-size:.875rem;margin-bottom:24px;">Buy and sell pre-owned branded fashion</p>

      <?php if($error):   ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
      <?php if($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>

      <?php if(!$success): ?>
      <form method="POST" action="register.php">

        <div class="two-col">
          <div class="form-group">
            <label for="first_name">First Name *</label>
            <input type="text" id="first_name" name="first_name" class="form-control"
                   placeholder="John" value="<?= htmlspecialchars($fn) ?>" required>
          </div>
          <div class="form-group">
            <label for="last_name">Last Name *</label>
            <input type="text" id="last_name" name="last_name" class="form-control"
                   placeholder="Doe" value="<?= htmlspecialchars($ln) ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label for="email">Email Address *</label>
          <input type="email" id="email" name="email" class="form-control"
                 placeholder="john@example.com" value="<?= htmlspecialchars($email) ?>" required>
        </div>

        <div class="form-group">
          <label for="phone">Phone Number</label>
          <input type="tel" id="phone" name="phone" class="form-control"
                 placeholder="082 000 0000" value="<?= htmlspecialchars($phone) ?>">
        </div>

        <div class="two-col">
          <div class="form-group">
            <label for="password">Password *</label>
            <input type="password" id="password" name="password" class="form-control"
                   placeholder="Min 6 characters" required minlength="6">
          </div>
          <div class="form-group">
            <label for="confirm">Confirm Password *</label>
            <input type="password" id="confirm" name="confirm" class="form-control"
                   placeholder="Repeat password" required minlength="6">
          </div>
        </div>

        <button type="submit" class="btn btn-accent" style="width:100%;margin-top:8px;padding:13px;">
          Create My Account →
        </button>

      </form>
      <?php endif; ?>

      <p style="text-align:center;margin-top:20px;font-size:.875rem;color:var(--muted);">
        Already have an account?
        <a href="login.php" style="color:var(--primary);font-weight:600;">Sign in</a>
      </p>

    </div>
  </div>
</div>

<footer>
  <p>© <?= date('Y') ?> <span class="brand">Pastimes</span> – ST10440743 – WEDE6020</p>
</footer>
</body>
</html>
