<?php
/**
 * shop.php  –  Main eShop Page
 * Displays items table with AddToCart and ShowCart buttons.
 * Uses Cart class for all cart operations.
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
if(!isset($_SESSION['user_id'])){ header('Location: login.php'); exit; }

require_once 'DBConn.php';
require_once 'classes/Cart.php';

$cart = new Cart();
$msg  = '';

// ProcessInput handles add/remove/update/empty via Cart class
if($_SERVER['REQUEST_METHOD']==='POST'){
    $msg = $cart->ProcessInput($conn);
}

// Fetch all available items as associative array
$result = $conn->query("SELECT * FROM tblClothes WHERE status='available' ORDER BY created_at DESC");
$items  = [];
while($row = $result->fetch_assoc()) $items[] = $row;

$conn->close();
$fullName  = htmlspecialchars($_SESSION['first_name'].' '.$_SESSION['last_name']);
$cartCount = $cart->GetCount();

// ShowCart flag
$showCart = isset($_GET['view']) && $_GET['view']==='cart';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Shop – Pastimes</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="user-bar">
  <span>👤 User <strong><?=$fullName?></strong> is logged in</span>
  <div style="display:flex;gap:16px">
    <a href="history.php">My Orders</a>
    <a href="messages.php">Messages</a>
    <a href="logout.php">Logout</a>
  </div>
</div>

<nav class="navbar">
  <a class="navbar-brand" href="index.php">Pastimes</a>
  <ul class="navbar-links">
    <li><a href="index.php">Home</a></li>
    <li><a href="shop.php" class="active">Shop</a></li>
    <li><a href="shop.php?view=cart">🛒 Cart <span class="cart-badge"><?=$cartCount?></span></a></li>
    <li><a href="history.php">Orders</a></li>
    <li><a href="seller/requestItem.php">Sell</a></li>
    <?php if(isset($_SESSION['role'])&&$_SESSION['role']==='admin'):?>
      <li><a href="admin/dashboard.php">Admin</a></li>
    <?php endif;?>
    <li><a href="logout.php" class="btn btn-accent btn-sm">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:40px;padding-bottom:80px">

  <?php if($msg): ?>
    <div class="alert alert-success"><?=$msg?></div>
  <?php endif; ?>

  <?php if($showCart): ?>
    <!-- ── ShowCart View ────────────────────────── -->
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px">
      <div>
        <h2 class="section-title" style="margin-bottom:4px">🛒 Your Shopping Cart</h2>
        <p style="color:var(--muted);font-size:.9rem"><?=$cartCount?> item<?=$cartCount!==1?'s':''?> · Total: <strong style="color:var(--accent)">R <?=number_format($cart->GetTotal(),2)?></strong></p>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <a href="shop.php" class="btn btn-ghost">← Continue Shopping</a>
        <a href="checkout.php" class="btn btn-primary">Checkout →</a>
      </div>
    </div>
    <?= $cart->ShowCart() ?>

    <?php if($cartCount>0): ?>
    <div style="margin-top:20px;display:flex;justify-content:flex-end;gap:12px;flex-wrap:wrap">
      <form method="POST">
        <button type="submit" name="empty_cart" class="btn btn-danger" onclick="return confirm('Clear entire cart?')">🗑 Empty Cart</button>
      </form>
      <a href="checkout.php" class="btn btn-primary btn-lg">Proceed to Checkout →</a>
    </div>
    <?php endif; ?>

  <?php else: ?>
    <!-- ── Shop / Items Table ─────────────────── -->
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px">
      <div>
        <h2 class="section-title" style="margin-bottom:4px">Browse All Items</h2>
        <p style="color:var(--muted);font-size:.9rem"><?=count($items)?> item<?=count($items)!==1?'s':''?> available</p>
      </div>
      <a href="shop.php?view=cart" class="btn btn-ghost">🛒 View Cart <span class="cart-badge" style="margin-left:4px"><?=$cartCount?></span></a>
    </div>

    <?php if(empty($items)): ?>
      <div class="alert alert-info">No items available right now. Check back soon!</div>
    <?php else: ?>

    <!-- Items Table (as per rubric) -->
    <div class="table-wrapper" style="margin-bottom:48px">
      <table>
        <thead>
          <tr>
            <th>Image</th><th>Item</th><th>Brand</th><th>Size</th>
            <th>Condition</th><th>Stock</th><th>Price</th><th>Add to Cart</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($items as $item): ?>
          <tr>
            <td><img src="images/<?=htmlspecialchars($item['image_filename'])?>" alt="" style="width:64px;height:64px;object-fit:cover;border-radius:10px;" onerror="this.src='images/item1.jpg'"></td>
            <td><strong style="color:var(--white)"><?=htmlspecialchars($item['title'])?></strong><br><span style="font-size:.78rem;color:var(--muted)"><?=htmlspecialchars(substr($item['description'],0,50))?>...</span></td>
            <td><span class="role-tag role-seller"><?=htmlspecialchars($item['brand'])?></span></td>
            <td><?=htmlspecialchars($item['size'])?></td>
            <td><span class="condition-badge badge-<?=strtolower($item['item_condition'])?>"><?=htmlspecialchars($item['item_condition'])?></span></td>
            <td><?=$item['quantity']>0?"<span style='color:var(--success)'>{$item['quantity']} left</span>":"<span style='color:var(--danger)'>Out of stock</span>"?></td>
            <td><strong style="color:var(--accent);font-size:1.05rem">R <?=number_format($item['sell_price'],2)?></strong></td>
            <td>
              <?php if($item['quantity']>0): ?>
              <form method="POST">
                <input type="hidden" name="item_id" value="<?=$item['item_id']?>">
                <button type="submit" name="add_to_cart" class="btn btn-primary btn-sm">+ Add to Cart</button>
              </form>
              <?php else: ?>
                <span style="color:var(--muted);font-size:.8rem">Unavailable</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- ShowCart Button (rubric) -->
    <div style="text-align:center;margin-bottom:48px">
      <a href="shop.php?view=cart" class="btn btn-primary btn-lg">🛒 ShowCart — View My Cart (<?=$cartCount?> item<?=$cartCount!==1?'s':''?>)</a>
    </div>

    <!-- Card Grid View -->
    <div style="margin-bottom:16px"><h3 style="color:var(--white);font-size:1.3rem;font-weight:700">Card View</h3></div>
    <div class="product-grid">
      <?php foreach($items as $item): ?>
      <div class="product-card">
        <div class="img-wrap">
          <img src="images/<?=htmlspecialchars($item['image_filename'])?>" alt="<?=htmlspecialchars($item['title'])?>" onerror="this.src='images/item1.jpg'">
          <div class="img-overlay"></div>
        </div>
        <div class="product-info">
          <div class="brand-tag"><?=htmlspecialchars($item['brand'])?></div>
          <h3><?=htmlspecialchars($item['title'])?></h3>
          <div class="meta">Size <?=htmlspecialchars($item['size'])?> · <?=$item['quantity']?> in stock</div>
          <span class="condition-badge badge-<?=strtolower($item['item_condition'])?>"><?=htmlspecialchars($item['item_condition'])?></span>
          <div class="price">R <?=number_format($item['sell_price'],2)?></div>
          <?php if($item['quantity']>0): ?>
          <form method="POST">
            <input type="hidden" name="item_id" value="<?=$item['item_id']?>">
            <button type="submit" name="add_to_cart" class="btn btn-primary" style="width:100%">+ Add to Cart</button>
          </form>
          <?php else: ?>
            <button class="btn btn-ghost" disabled style="width:100%;opacity:.5">Out of Stock</button>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<footer>
  <p>© <?=date('Y')?> <span class="brand">Pastimes</span> &nbsp;|&nbsp; ST10440743</p>
</footer>
</body>
</html>
