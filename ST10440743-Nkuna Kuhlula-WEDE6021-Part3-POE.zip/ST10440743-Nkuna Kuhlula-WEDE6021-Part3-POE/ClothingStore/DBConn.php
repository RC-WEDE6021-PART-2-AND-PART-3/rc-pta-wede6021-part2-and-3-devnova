<?php
/**
 * DBConn.php
 * Connects to ClothingStore. Creates the database
 * automatically if it does not exist yet.
 * Student : Nkuna Kuhlula  |  ST10440743
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ClothingStore');

// Step 1: Connect WITHOUT specifying a database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);

if ($conn->connect_error) {
    die('<div style="font-family:Calibri;color:#c0392b;padding:20px;font-size:16px;">'
        . '<strong>MySQL connection failed:</strong> ' . $conn->connect_error
        . '<br><br>Make sure XAMPP MySQL is running.</div>');
}

// Step 2: Create the database if it does not exist
$conn->query("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->query("USE `" . DB_NAME . "`");
$conn->set_charset('utf8mb4');
?>
