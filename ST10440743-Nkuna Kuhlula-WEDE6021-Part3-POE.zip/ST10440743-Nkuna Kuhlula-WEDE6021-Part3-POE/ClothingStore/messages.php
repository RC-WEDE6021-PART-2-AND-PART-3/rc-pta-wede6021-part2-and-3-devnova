<?php
/**
 * messages.php  –  In-App Messaging for users
 * Student : Nkuna Kuhlula  |  ST10440743
 */
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

require_once 'DBConn.php';

$userId   = (int)$_SESSION['user_id'];
$fullName = htmlspecialchars($_SESSION['first_name'] . ' ' . $_SESSION['last_name']);
$msg = '';

// Send message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_msg'])) {
    $to      = (int)  ($_POST['receiver_id'] ?? 0);
    $subject = trim($_POST['subject'] ?? '');
    $body    = trim($_POST['body']    ?? '');

    if ($to && $subject && $body) {
        $senderName = $_SESSION['first_name'] . ' ' . $_SESSION['last_name'];
        $stmt = $conn->prepare(
            "INSERT INTO tblMessage (sender_id, sender_name, receiver_id, subject, body)
             VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->bind_param('isiss', $userId, $senderName, $to, $subject, $body);
        if ($stmt->execute()) $msg = 'Message sent!';
        $stmt->close();
    }
}

// Mark message as read
if (isset($_GET['read'])) {
    $mid = (int)$_GET['read'];
    $conn->query("UPDATE tblMessage SET is_read=1 WHERE message_id=$mid AND receiver_id=$userId");
}

// Fetch inbox
$inbox = $conn->prepare(
    "SELECT m.*, m.sender_name
     FROM tblMessage m
     WHERE m.receiver_id = ?
     ORDER BY m.sent_at DESC"
);
$inbox->bind_param('i', $userId);
$inbox->execute();
$inboxRows = $inbox->get_result()->fetch_all(MYSQLI_ASSOC);
$inbox->close();

// Fetch sent
$sent = $conn->prepare(
    "SELECT m.*, u.first_name, u.last_name
     FROM tblMessage m
     LEFT JOIN tblUser u ON u.user_id = m.receiver_id
     WHERE m.sender_id = ?
     ORDER BY m.sent_at DESC"
);
$sent->bind_param('i', $userId);
$sent->execute();
$sentRows = $sent->get_result()->fetch_all(MYSQLI_ASSOC);
$sent->close();

// Users to message
$users = $conn->query(
    "SELECT user_id, first_name, last_name, role FROM tblUser
     WHERE user_id != $userId AND is_verified = 1"
)->fetch_all(MYSQLI_ASSOC);

$conn->close();
$unread = count(array_filter($inboxRows, fn($r) => $r['is_read'] == 0));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Messages – Pastimes</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="user-bar">
  <span>👤 <strong><?= $fullName ?></strong></span>
  <a href="logout.php">Logout</a>
</div>
<nav class="navbar">
  <a class="navbar-brand" href="index.php">Pastimes</a>
  <ul class="navbar-links">
    <li><a href="shop.php">Shop</a></li>
    <li><a href="cart.php">Cart</a></li>
    <li><a href="messages.php" class="active">
      Messages <?php if ($unread): ?><span class="cart-badge"><?= $unread ?></span><?php endif; ?>
    </a></li>
    <li><a href="logout.php" class="btn btn-accent btn-sm">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:40px;padding-bottom:80px">
  <h2 class="section-title" style="margin-bottom:32px">💬 Messages</h2>

  <?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:32px">

    <!-- Inbox -->
    <div class="card">
      <div class="card-header">
        <h2>📥 Inbox <?php if ($unread): ?><span class="cart-badge"><?= $unread ?> new</span><?php endif; ?></h2>
      </div>
      <div class="card-body" style="padding:0;max-height:400px;overflow-y:auto">
        <?php if (empty($inboxRows)): ?>
          <div style="padding:24px;color:var(--muted);text-align:center">No messages yet</div>
        <?php else: foreach ($inboxRows as $m): ?>
          <div style="padding:16px 20px;border-bottom:1px solid var(--border);background:<?= $m['is_read'] ? 'transparent' : 'rgba(108,99,255,0.06)' ?>">
            <div style="display:flex;justify-content:space-between;margin-bottom:4px">
              <strong style="color:var(--white);font-size:.875rem">
                <?= htmlspecialchars($m['sender_name'] ?? 'Unknown') ?>
              </strong>
              <span style="font-size:.75rem;color:var(--muted)"><?= date('d M', strtotime($m['sent_at'])) ?></span>
            </div>
            <div style="font-size:.85rem;font-weight:600;color:var(--text);margin-bottom:4px">
              <?= htmlspecialchars($m['subject']) ?>
            </div>
            <div style="font-size:.82rem;color:var(--muted)">
              <?= htmlspecialchars(substr($m['body'], 0, 80)) ?>...
            </div>
            <?php if (!$m['is_read']): ?>
              <a href="messages.php?read=<?= $m['message_id'] ?>" style="font-size:.75rem;color:var(--primary)">Mark as read</a>
            <?php endif; ?>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>

    <!-- Sent -->
    <div class="card">
      <div class="card-header"><h2>📤 Sent</h2></div>
      <div class="card-body" style="padding:0;max-height:400px;overflow-y:auto">
        <?php if (empty($sentRows)): ?>
          <div style="padding:24px;color:var(--muted);text-align:center">No sent messages</div>
        <?php else: foreach ($sentRows as $m): ?>
          <div style="padding:16px 20px;border-bottom:1px solid var(--border)">
            <div style="display:flex;justify-content:space-between;margin-bottom:4px">
              <strong style="color:var(--white);font-size:.875rem">
                To: <?= htmlspecialchars(($m['first_name'] ?? 'Unknown') . ' ' . ($m['last_name'] ?? '')) ?>
              </strong>
              <span style="font-size:.75rem;color:var(--muted)"><?= date('d M', strtotime($m['sent_at'])) ?></span>
            </div>
            <div style="font-size:.85rem;color:var(--text)"><?= htmlspecialchars($m['subject']) ?></div>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>

  <!-- Compose -->
  <div class="card">
    <div class="card-header"><h2>✉️ Compose Message</h2></div>
    <div class="card-body">
      <form method="POST" style="display:grid;gap:16px">
        <div class="form-group" style="margin:0">
          <label>Send To</label>
          <select name="receiver_id" class="form-control" required>
            <option value="">— Select recipient —</option>
            <?php foreach ($users as $u): ?>
              <option value="<?= $u['user_id'] ?>">
                <?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name']) ?> (<?= $u['role'] ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group" style="margin:0">
          <label>Subject</label>
          <input type="text" name="subject" class="form-control" placeholder="Subject" required>
        </div>
        <div class="form-group" style="margin:0">
          <label>Message</label>
          <textarea name="body" class="form-control" rows="4"
                    placeholder="Write your message..." required style="resize:vertical"></textarea>
        </div>
        <div>
          <button type="submit" name="send_msg" class="btn btn-primary">Send Message →</button>
        </div>
      </form>
    </div>
  </div>
</div>

<footer><p>© <?= date('Y') ?> <span class="brand">Pastimes</span> &nbsp;|&nbsp; ST10440743</p></footer>
</body>
</html>
